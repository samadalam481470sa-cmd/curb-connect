"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

  // ../../packages/pricing/src/version.ts
  var ENGINE_VERSION = "1.0.0";
  var ROOF_TAKEOFF_VERSION = "roof-takeoff@1.0.0";
  var ROOF_WASTE_VERSION = "roof-waste@1.0.0";
  var CURB_QUANTITY_VERSION = "curb-quantity@1.0.0";
  var CURB_RECIPE_VERSION = "curb-recipe@1.0.0";

  // ../../node_modules/decimal.js/decimal.mjs
  var EXP_LIMIT = 9e15;
  var MAX_DIGITS = 1e9;
  var NUMERALS = "0123456789abcdef";
  var LN10 = "2.3025850929940456840179914546843642076011014886287729760333279009675726096773524802359972050895982983419677840422862486334095254650828067566662873690987816894829072083255546808437998948262331985283935053089653777326288461633662222876982198867465436674744042432743651550489343149393914796194044002221051017141748003688084012647080685567743216228355220114804663715659121373450747856947683463616792101806445070648000277502684916746550586856935673420670581136429224554405758925724208241314695689016758940256776311356919292033376587141660230105703089634572075440370847469940168269282808481184289314848524948644871927809676271275775397027668605952496716674183485704422507197965004714951050492214776567636938662976979522110718264549734772662425709429322582798502585509785265383207606726317164309505995087807523710333101197857547331541421808427543863591778117054309827482385045648019095610299291824318237525357709750539565187697510374970888692180205189339507238539205144634197265287286965110862571492198849978748873771345686209167058";
  var PI = "3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679821480865132823066470938446095505822317253594081284811174502841027019385211055596446229489549303819644288109756659334461284756482337867831652712019091456485669234603486104543266482133936072602491412737245870066063155881748815209209628292540917153643678925903600113305305488204665213841469519415116094330572703657595919530921861173819326117931051185480744623799627495673518857527248912279381830119491298336733624406566430860213949463952247371907021798609437027705392171762931767523846748184676694051320005681271452635608277857713427577896091736371787214684409012249534301465495853710507922796892589235420199561121290219608640344181598136297747713099605187072113499999983729780499510597317328160963185950244594553469083026425223082533446850352619311881710100031378387528865875332083814206171776691473035982534904287554687311595628638823537875937519577818577805321712268066130019278766111959092164201989380952572010654858632789";
  var DEFAULTS = {
    // These values must be integers within the stated ranges (inclusive).
    // Most of these values can be changed at run-time using the `Decimal.config` method.
    // The maximum number of significant digits of the result of a calculation or base conversion.
    // E.g. `Decimal.config({ precision: 20 });`
    precision: 20,
    // 1 to MAX_DIGITS
    // The rounding mode used when rounding to `precision`.
    //
    // ROUND_UP         0 Away from zero.
    // ROUND_DOWN       1 Towards zero.
    // ROUND_CEIL       2 Towards +Infinity.
    // ROUND_FLOOR      3 Towards -Infinity.
    // ROUND_HALF_UP    4 Towards nearest neighbour. If equidistant, up.
    // ROUND_HALF_DOWN  5 Towards nearest neighbour. If equidistant, down.
    // ROUND_HALF_EVEN  6 Towards nearest neighbour. If equidistant, towards even neighbour.
    // ROUND_HALF_CEIL  7 Towards nearest neighbour. If equidistant, towards +Infinity.
    // ROUND_HALF_FLOOR 8 Towards nearest neighbour. If equidistant, towards -Infinity.
    //
    // E.g.
    // `Decimal.rounding = 4;`
    // `Decimal.rounding = Decimal.ROUND_HALF_UP;`
    rounding: 4,
    // 0 to 8
    // The modulo mode used when calculating the modulus: a mod n.
    // The quotient (q = a / n) is calculated according to the corresponding rounding mode.
    // The remainder (r) is calculated as: r = a - n * q.
    //
    // UP         0 The remainder is positive if the dividend is negative, else is negative.
    // DOWN       1 The remainder has the same sign as the dividend (JavaScript %).
    // FLOOR      3 The remainder has the same sign as the divisor (Python %).
    // HALF_EVEN  6 The IEEE 754 remainder function.
    // EUCLID     9 Euclidian division. q = sign(n) * floor(a / abs(n)). Always positive.
    //
    // Truncated division (1), floored division (3), the IEEE 754 remainder (6), and Euclidian
    // division (9) are commonly used for the modulus operation. The other rounding modes can also
    // be used, but they may not give useful results.
    modulo: 1,
    // 0 to 9
    // The exponent value at and beneath which `toString` returns exponential notation.
    // JavaScript numbers: -7
    toExpNeg: -7,
    // 0 to -EXP_LIMIT
    // The exponent value at and above which `toString` returns exponential notation.
    // JavaScript numbers: 21
    toExpPos: 21,
    // 0 to EXP_LIMIT
    // The minimum exponent value, beneath which underflow to zero occurs.
    // JavaScript numbers: -324  (5e-324)
    minE: -EXP_LIMIT,
    // -1 to -EXP_LIMIT
    // The maximum exponent value, above which overflow to Infinity occurs.
    // JavaScript numbers: 308  (1.7976931348623157e+308)
    maxE: EXP_LIMIT,
    // 1 to EXP_LIMIT
    // Whether to use cryptographically-secure random number generation, if available.
    crypto: false
    // true/false
  };
  var inexact;
  var quadrant;
  var external = true;
  var decimalError = "[DecimalError] ";
  var invalidArgument = decimalError + "Invalid argument: ";
  var precisionLimitExceeded = decimalError + "Precision limit exceeded";
  var cryptoUnavailable = decimalError + "crypto unavailable";
  var tag = "[object Decimal]";
  var mathfloor = Math.floor;
  var mathpow = Math.pow;
  var isBinary = /^0b([01]+(\.[01]*)?|\.[01]+)(p[+-]?\d+)?$/i;
  var isHex = /^0x([0-9a-f]+(\.[0-9a-f]*)?|\.[0-9a-f]+)(p[+-]?\d+)?$/i;
  var isOctal = /^0o([0-7]+(\.[0-7]*)?|\.[0-7]+)(p[+-]?\d+)?$/i;
  var isDecimal = /^(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i;
  var BASE = 1e7;
  var LOG_BASE = 7;
  var MAX_SAFE_INTEGER = 9007199254740991;
  var LN10_PRECISION = LN10.length - 1;
  var PI_PRECISION = PI.length - 1;
  var P = { toStringTag: tag };
  P.absoluteValue = P.abs = function() {
    var x = new this.constructor(this);
    if (x.s < 0) x.s = 1;
    return finalise(x);
  };
  P.ceil = function() {
    return finalise(new this.constructor(this), this.e + 1, 2);
  };
  P.clampedTo = P.clamp = function(min2, max2) {
    var k, x = this, Ctor = x.constructor;
    min2 = new Ctor(min2);
    max2 = new Ctor(max2);
    if (!min2.s || !max2.s) return new Ctor(NaN);
    if (min2.gt(max2)) throw Error(invalidArgument + max2);
    k = x.cmp(min2);
    return k < 0 ? min2 : x.cmp(max2) > 0 ? max2 : new Ctor(x);
  };
  P.comparedTo = P.cmp = function(y) {
    var i, j, xdL, ydL, x = this, xd = x.d, yd = (y = new x.constructor(y)).d, xs = x.s, ys = y.s;
    if (!xd || !yd) {
      return !xs || !ys ? NaN : xs !== ys ? xs : xd === yd ? 0 : !xd ^ xs < 0 ? 1 : -1;
    }
    if (!xd[0] || !yd[0]) return xd[0] ? xs : yd[0] ? -ys : 0;
    if (xs !== ys) return xs;
    if (x.e !== y.e) return x.e > y.e ^ xs < 0 ? 1 : -1;
    xdL = xd.length;
    ydL = yd.length;
    for (i = 0, j = xdL < ydL ? xdL : ydL; i < j; ++i) {
      if (xd[i] !== yd[i]) return xd[i] > yd[i] ^ xs < 0 ? 1 : -1;
    }
    return xdL === ydL ? 0 : xdL > ydL ^ xs < 0 ? 1 : -1;
  };
  P.cosine = P.cos = function() {
    var pr, rm, x = this, Ctor = x.constructor;
    if (!x.d) return new Ctor(NaN);
    if (!x.d[0]) return new Ctor(1);
    pr = Ctor.precision;
    rm = Ctor.rounding;
    Ctor.precision = pr + Math.max(x.e, x.sd()) + LOG_BASE;
    Ctor.rounding = 1;
    x = cosine(Ctor, toLessThanHalfPi(Ctor, x));
    Ctor.precision = pr;
    Ctor.rounding = rm;
    return finalise(quadrant == 2 || quadrant == 3 ? x.neg() : x, pr, rm, true);
  };
  P.cubeRoot = P.cbrt = function() {
    var e, m, n, r, rep, s, sd, t, t3, t3plusx, x = this, Ctor = x.constructor;
    if (!x.isFinite() || x.isZero()) return new Ctor(x);
    external = false;
    s = x.s * mathpow(x.s * x, 1 / 3);
    if (!s || Math.abs(s) == 1 / 0) {
      n = digitsToString(x.d);
      e = x.e;
      if (s = (e - n.length + 1) % 3) n += s == 1 || s == -2 ? "0" : "00";
      s = mathpow(n, 1 / 3);
      e = mathfloor((e + 1) / 3) - (e % 3 == (e < 0 ? -1 : 2));
      if (s == 1 / 0) {
        n = "5e" + e;
      } else {
        n = s.toExponential();
        n = n.slice(0, n.indexOf("e") + 1) + e;
      }
      r = new Ctor(n);
      r.s = x.s;
    } else {
      r = new Ctor(s.toString());
    }
    sd = (e = Ctor.precision) + 3;
    for (; ; ) {
      t = r;
      t3 = t.times(t).times(t);
      t3plusx = t3.plus(x);
      r = divide(t3plusx.plus(x).times(t), t3plusx.plus(t3), sd + 2, 1);
      if (digitsToString(t.d).slice(0, sd) === (n = digitsToString(r.d)).slice(0, sd)) {
        n = n.slice(sd - 3, sd + 1);
        if (n == "9999" || !rep && n == "4999") {
          if (!rep) {
            finalise(t, e + 1, 0);
            if (t.times(t).times(t).eq(x)) {
              r = t;
              break;
            }
          }
          sd += 4;
          rep = 1;
        } else {
          if (!+n || !+n.slice(1) && n.charAt(0) == "5") {
            finalise(r, e + 1, 1);
            m = !r.times(r).times(r).eq(x);
          }
          break;
        }
      }
    }
    external = true;
    return finalise(r, e, Ctor.rounding, m);
  };
  P.decimalPlaces = P.dp = function() {
    var w, d = this.d, n = NaN;
    if (d) {
      w = d.length - 1;
      n = (w - mathfloor(this.e / LOG_BASE)) * LOG_BASE;
      w = d[w];
      if (w) for (; w % 10 == 0; w /= 10) n--;
      if (n < 0) n = 0;
    }
    return n;
  };
  P.dividedBy = P.div = function(y) {
    return divide(this, new this.constructor(y));
  };
  P.dividedToIntegerBy = P.divToInt = function(y) {
    var x = this, Ctor = x.constructor;
    return finalise(divide(x, new Ctor(y), 0, 1, 1), Ctor.precision, Ctor.rounding);
  };
  P.equals = P.eq = function(y) {
    return this.cmp(y) === 0;
  };
  P.floor = function() {
    return finalise(new this.constructor(this), this.e + 1, 3);
  };
  P.greaterThan = P.gt = function(y) {
    return this.cmp(y) > 0;
  };
  P.greaterThanOrEqualTo = P.gte = function(y) {
    var k = this.cmp(y);
    return k == 1 || k === 0;
  };
  P.hyperbolicCosine = P.cosh = function() {
    var k, n, pr, rm, len, x = this, Ctor = x.constructor, one = new Ctor(1);
    if (!x.isFinite()) return new Ctor(x.s ? 1 / 0 : NaN);
    if (x.isZero()) return one;
    pr = Ctor.precision;
    rm = Ctor.rounding;
    Ctor.precision = pr + Math.max(x.e, x.sd()) + 4;
    Ctor.rounding = 1;
    len = x.d.length;
    if (len < 32) {
      k = Math.ceil(len / 3);
      n = (1 / tinyPow(4, k)).toString();
    } else {
      k = 16;
      n = "2.3283064365386962890625e-10";
    }
    x = taylorSeries(Ctor, 1, x.times(n), new Ctor(1), true);
    var cosh2_x, i = k, d8 = new Ctor(8);
    for (; i--; ) {
      cosh2_x = x.times(x);
      x = one.minus(cosh2_x.times(d8.minus(cosh2_x.times(d8))));
    }
    return finalise(x, Ctor.precision = pr, Ctor.rounding = rm, true);
  };
  P.hyperbolicSine = P.sinh = function() {
    var k, pr, rm, len, x = this, Ctor = x.constructor;
    if (!x.isFinite() || x.isZero()) return new Ctor(x);
    pr = Ctor.precision;
    rm = Ctor.rounding;
    Ctor.precision = pr + Math.max(x.e, x.sd()) + 4;
    Ctor.rounding = 1;
    len = x.d.length;
    if (len < 3) {
      x = taylorSeries(Ctor, 2, x, x, true);
    } else {
      k = 1.4 * Math.sqrt(len);
      k = k > 16 ? 16 : k | 0;
      x = x.times(1 / tinyPow(5, k));
      x = taylorSeries(Ctor, 2, x, x, true);
      var sinh2_x, d5 = new Ctor(5), d16 = new Ctor(16), d20 = new Ctor(20);
      for (; k--; ) {
        sinh2_x = x.times(x);
        x = x.times(d5.plus(sinh2_x.times(d16.times(sinh2_x).plus(d20))));
      }
    }
    Ctor.precision = pr;
    Ctor.rounding = rm;
    return finalise(x, pr, rm, true);
  };
  P.hyperbolicTangent = P.tanh = function() {
    var pr, rm, x = this, Ctor = x.constructor;
    if (!x.isFinite()) return new Ctor(x.s);
    if (x.isZero()) return new Ctor(x);
    pr = Ctor.precision;
    rm = Ctor.rounding;
    Ctor.precision = pr + 7;
    Ctor.rounding = 1;
    return divide(x.sinh(), x.cosh(), Ctor.precision = pr, Ctor.rounding = rm);
  };
  P.inverseCosine = P.acos = function() {
    var x = this, Ctor = x.constructor, k = x.abs().cmp(1), pr = Ctor.precision, rm = Ctor.rounding;
    if (k !== -1) {
      return k === 0 ? x.isNeg() ? getPi(Ctor, pr, rm) : new Ctor(0) : new Ctor(NaN);
    }
    if (x.isZero()) return getPi(Ctor, pr + 4, rm).times(0.5);
    Ctor.precision = pr + 6;
    Ctor.rounding = 1;
    x = new Ctor(1).minus(x).div(x.plus(1)).sqrt().atan();
    Ctor.precision = pr;
    Ctor.rounding = rm;
    return x.times(2);
  };
  P.inverseHyperbolicCosine = P.acosh = function() {
    var pr, rm, x = this, Ctor = x.constructor;
    if (x.lte(1)) return new Ctor(x.eq(1) ? 0 : NaN);
    if (!x.isFinite()) return new Ctor(x);
    pr = Ctor.precision;
    rm = Ctor.rounding;
    Ctor.precision = pr + Math.max(Math.abs(x.e), x.sd()) + 4;
    Ctor.rounding = 1;
    external = false;
    x = x.times(x).minus(1).sqrt().plus(x);
    external = true;
    Ctor.precision = pr;
    Ctor.rounding = rm;
    return x.ln();
  };
  P.inverseHyperbolicSine = P.asinh = function() {
    var pr, rm, x = this, Ctor = x.constructor;
    if (!x.isFinite() || x.isZero()) return new Ctor(x);
    pr = Ctor.precision;
    rm = Ctor.rounding;
    Ctor.precision = pr + 2 * Math.max(Math.abs(x.e), x.sd()) + 6;
    Ctor.rounding = 1;
    external = false;
    x = x.times(x).plus(1).sqrt().plus(x);
    external = true;
    Ctor.precision = pr;
    Ctor.rounding = rm;
    return x.ln();
  };
  P.inverseHyperbolicTangent = P.atanh = function() {
    var pr, rm, wpr, xsd, x = this, Ctor = x.constructor;
    if (!x.isFinite()) return new Ctor(NaN);
    if (x.e >= 0) return new Ctor(x.abs().eq(1) ? x.s / 0 : x.isZero() ? x : NaN);
    pr = Ctor.precision;
    rm = Ctor.rounding;
    xsd = x.sd();
    if (Math.max(xsd, pr) < 2 * -x.e - 1) return finalise(new Ctor(x), pr, rm, true);
    Ctor.precision = wpr = xsd - x.e;
    x = divide(x.plus(1), new Ctor(1).minus(x), wpr + pr, 1);
    Ctor.precision = pr + 4;
    Ctor.rounding = 1;
    x = x.ln();
    Ctor.precision = pr;
    Ctor.rounding = rm;
    return x.times(0.5);
  };
  P.inverseSine = P.asin = function() {
    var halfPi, k, pr, rm, x = this, Ctor = x.constructor;
    if (x.isZero()) return new Ctor(x);
    k = x.abs().cmp(1);
    pr = Ctor.precision;
    rm = Ctor.rounding;
    if (k !== -1) {
      if (k === 0) {
        halfPi = getPi(Ctor, pr + 4, rm).times(0.5);
        halfPi.s = x.s;
        return halfPi;
      }
      return new Ctor(NaN);
    }
    Ctor.precision = pr + 6;
    Ctor.rounding = 1;
    x = x.div(new Ctor(1).minus(x.times(x)).sqrt().plus(1)).atan();
    Ctor.precision = pr;
    Ctor.rounding = rm;
    return x.times(2);
  };
  P.inverseTangent = P.atan = function() {
    var i, j, k, n, px, t, r, wpr, x2, x = this, Ctor = x.constructor, pr = Ctor.precision, rm = Ctor.rounding;
    if (!x.isFinite()) {
      if (!x.s) return new Ctor(NaN);
      if (pr + 4 <= PI_PRECISION) {
        r = getPi(Ctor, pr + 4, rm).times(0.5);
        r.s = x.s;
        return r;
      }
    } else if (x.isZero()) {
      return new Ctor(x);
    } else if (x.abs().eq(1) && pr + 4 <= PI_PRECISION) {
      r = getPi(Ctor, pr + 4, rm).times(0.25);
      r.s = x.s;
      return r;
    }
    Ctor.precision = wpr = pr + 10;
    Ctor.rounding = 1;
    k = Math.min(28, wpr / LOG_BASE + 2 | 0);
    for (i = k; i; --i) x = x.div(x.times(x).plus(1).sqrt().plus(1));
    external = false;
    j = Math.ceil(wpr / LOG_BASE);
    n = 1;
    x2 = x.times(x);
    r = new Ctor(x);
    px = x;
    for (; i !== -1; ) {
      px = px.times(x2);
      t = r.minus(px.div(n += 2));
      px = px.times(x2);
      r = t.plus(px.div(n += 2));
      if (r.d[j] !== void 0) for (i = j; r.d[i] === t.d[i] && i--; ) ;
    }
    if (k) r = r.times(2 << k - 1);
    external = true;
    return finalise(r, Ctor.precision = pr, Ctor.rounding = rm, true);
  };
  P.isFinite = function() {
    return !!this.d;
  };
  P.isInteger = P.isInt = function() {
    return !!this.d && mathfloor(this.e / LOG_BASE) > this.d.length - 2;
  };
  P.isNaN = function() {
    return !this.s;
  };
  P.isNegative = P.isNeg = function() {
    return this.s < 0;
  };
  P.isPositive = P.isPos = function() {
    return this.s > 0;
  };
  P.isZero = function() {
    return !!this.d && this.d[0] === 0;
  };
  P.lessThan = P.lt = function(y) {
    return this.cmp(y) < 0;
  };
  P.lessThanOrEqualTo = P.lte = function(y) {
    return this.cmp(y) < 1;
  };
  P.logarithm = P.log = function(base) {
    var isBase10, d, denominator, k, inf, num, sd, r, arg = this, Ctor = arg.constructor, pr = Ctor.precision, rm = Ctor.rounding, guard = 5;
    if (base == null) {
      base = new Ctor(10);
      isBase10 = true;
    } else {
      base = new Ctor(base);
      d = base.d;
      if (base.s < 0 || !d || !d[0] || base.eq(1)) return new Ctor(NaN);
      isBase10 = base.eq(10);
    }
    d = arg.d;
    if (arg.s < 0 || !d || !d[0] || arg.eq(1)) {
      return new Ctor(d && !d[0] ? -1 / 0 : arg.s != 1 ? NaN : d ? 0 : 1 / 0);
    }
    if (isBase10) {
      if (d.length > 1) {
        inf = true;
      } else {
        for (k = d[0]; k % 10 === 0; ) k /= 10;
        inf = k !== 1;
      }
    }
    external = false;
    sd = pr + guard;
    num = naturalLogarithm(arg, sd);
    denominator = isBase10 ? getLn10(Ctor, sd + 10) : naturalLogarithm(base, sd);
    r = divide(num, denominator, sd, 1);
    if (checkRoundingDigits(r.d, k = pr, rm)) {
      do {
        sd += 10;
        num = naturalLogarithm(arg, sd);
        denominator = isBase10 ? getLn10(Ctor, sd + 10) : naturalLogarithm(base, sd);
        r = divide(num, denominator, sd, 1);
        if (!inf) {
          if (+digitsToString(r.d).slice(k + 1, k + 15) + 1 == 1e14) {
            r = finalise(r, pr + 1, 0);
          }
          break;
        }
      } while (checkRoundingDigits(r.d, k += 10, rm));
    }
    external = true;
    return finalise(r, pr, rm);
  };
  P.minus = P.sub = function(y) {
    var d, e, i, j, k, len, pr, rm, xd, xe, xLTy, yd, x = this, Ctor = x.constructor;
    y = new Ctor(y);
    if (!x.d || !y.d) {
      if (!x.s || !y.s) y = new Ctor(NaN);
      else if (x.d) y.s = -y.s;
      else y = new Ctor(y.d || x.s !== y.s ? x : NaN);
      return y;
    }
    if (x.s != y.s) {
      y.s = -y.s;
      return x.plus(y);
    }
    xd = x.d;
    yd = y.d;
    pr = Ctor.precision;
    rm = Ctor.rounding;
    if (!xd[0] || !yd[0]) {
      if (yd[0]) y.s = -y.s;
      else if (xd[0]) y = new Ctor(x);
      else return new Ctor(rm === 3 ? -0 : 0);
      return external ? finalise(y, pr, rm) : y;
    }
    e = mathfloor(y.e / LOG_BASE);
    xe = mathfloor(x.e / LOG_BASE);
    xd = xd.slice();
    k = xe - e;
    if (k) {
      xLTy = k < 0;
      if (xLTy) {
        d = xd;
        k = -k;
        len = yd.length;
      } else {
        d = yd;
        e = xe;
        len = xd.length;
      }
      i = Math.max(Math.ceil(pr / LOG_BASE), len) + 2;
      if (k > i) {
        k = i;
        d.length = 1;
      }
      d.reverse();
      for (i = k; i--; ) d.push(0);
      d.reverse();
    } else {
      i = xd.length;
      len = yd.length;
      xLTy = i < len;
      if (xLTy) len = i;
      for (i = 0; i < len; i++) {
        if (xd[i] != yd[i]) {
          xLTy = xd[i] < yd[i];
          break;
        }
      }
      k = 0;
    }
    if (xLTy) {
      d = xd;
      xd = yd;
      yd = d;
      y.s = -y.s;
    }
    len = xd.length;
    for (i = yd.length - len; i > 0; --i) xd[len++] = 0;
    for (i = yd.length; i > k; ) {
      if (xd[--i] < yd[i]) {
        for (j = i; j && xd[--j] === 0; ) xd[j] = BASE - 1;
        --xd[j];
        xd[i] += BASE;
      }
      xd[i] -= yd[i];
    }
    for (; xd[--len] === 0; ) xd.pop();
    for (; xd[0] === 0; xd.shift()) --e;
    if (!xd[0]) return new Ctor(rm === 3 ? -0 : 0);
    y.d = xd;
    y.e = getBase10Exponent(xd, e);
    return external ? finalise(y, pr, rm) : y;
  };
  P.modulo = P.mod = function(y) {
    var q, x = this, Ctor = x.constructor;
    y = new Ctor(y);
    if (!x.d || !y.s || y.d && !y.d[0]) return new Ctor(NaN);
    if (!y.d || x.d && !x.d[0]) {
      return finalise(new Ctor(x), Ctor.precision, Ctor.rounding);
    }
    external = false;
    if (Ctor.modulo == 9) {
      q = divide(x, y.abs(), 0, 3, 1);
      q.s *= y.s;
    } else {
      q = divide(x, y, 0, Ctor.modulo, 1);
    }
    q = q.times(y);
    external = true;
    return x.minus(q);
  };
  P.naturalExponential = P.exp = function() {
    return naturalExponential(this);
  };
  P.naturalLogarithm = P.ln = function() {
    return naturalLogarithm(this);
  };
  P.negated = P.neg = function() {
    var x = new this.constructor(this);
    x.s = -x.s;
    return finalise(x);
  };
  P.plus = P.add = function(y) {
    var carry, d, e, i, k, len, pr, rm, xd, yd, x = this, Ctor = x.constructor;
    y = new Ctor(y);
    if (!x.d || !y.d) {
      if (!x.s || !y.s) y = new Ctor(NaN);
      else if (!x.d) y = new Ctor(y.d || x.s === y.s ? x : NaN);
      return y;
    }
    if (x.s != y.s) {
      y.s = -y.s;
      return x.minus(y);
    }
    xd = x.d;
    yd = y.d;
    pr = Ctor.precision;
    rm = Ctor.rounding;
    if (!xd[0] || !yd[0]) {
      if (!yd[0]) y = new Ctor(x);
      return external ? finalise(y, pr, rm) : y;
    }
    k = mathfloor(x.e / LOG_BASE);
    e = mathfloor(y.e / LOG_BASE);
    xd = xd.slice();
    i = k - e;
    if (i) {
      if (i < 0) {
        d = xd;
        i = -i;
        len = yd.length;
      } else {
        d = yd;
        e = k;
        len = xd.length;
      }
      k = Math.ceil(pr / LOG_BASE);
      len = k > len ? k + 1 : len + 1;
      if (i > len) {
        i = len;
        d.length = 1;
      }
      d.reverse();
      for (; i--; ) d.push(0);
      d.reverse();
    }
    len = xd.length;
    i = yd.length;
    if (len - i < 0) {
      i = len;
      d = yd;
      yd = xd;
      xd = d;
    }
    for (carry = 0; i; ) {
      carry = (xd[--i] = xd[i] + yd[i] + carry) / BASE | 0;
      xd[i] %= BASE;
    }
    if (carry) {
      xd.unshift(carry);
      ++e;
    }
    for (len = xd.length; xd[--len] == 0; ) xd.pop();
    y.d = xd;
    y.e = getBase10Exponent(xd, e);
    return external ? finalise(y, pr, rm) : y;
  };
  P.precision = P.sd = function(z) {
    var k, x = this;
    if (z !== void 0 && z !== !!z && z !== 1 && z !== 0) throw Error(invalidArgument + z);
    if (x.d) {
      k = getPrecision(x.d);
      if (z && x.e + 1 > k) k = x.e + 1;
    } else {
      k = NaN;
    }
    return k;
  };
  P.round = function() {
    var x = this, Ctor = x.constructor;
    return finalise(new Ctor(x), x.e + 1, Ctor.rounding);
  };
  P.sine = P.sin = function() {
    var pr, rm, x = this, Ctor = x.constructor;
    if (!x.isFinite()) return new Ctor(NaN);
    if (x.isZero()) return new Ctor(x);
    pr = Ctor.precision;
    rm = Ctor.rounding;
    Ctor.precision = pr + Math.max(x.e, x.sd()) + LOG_BASE;
    Ctor.rounding = 1;
    x = sine(Ctor, toLessThanHalfPi(Ctor, x));
    Ctor.precision = pr;
    Ctor.rounding = rm;
    return finalise(quadrant > 2 ? x.neg() : x, pr, rm, true);
  };
  P.squareRoot = P.sqrt = function() {
    var m, n, sd, r, rep, t, x = this, d = x.d, e = x.e, s = x.s, Ctor = x.constructor;
    if (s !== 1 || !d || !d[0]) {
      return new Ctor(!s || s < 0 && (!d || d[0]) ? NaN : d ? x : 1 / 0);
    }
    external = false;
    s = Math.sqrt(+x);
    if (s == 0 || s == 1 / 0) {
      n = digitsToString(d);
      if ((n.length + e) % 2 == 0) n += "0";
      s = Math.sqrt(n);
      e = mathfloor((e + 1) / 2) - (e < 0 || e % 2);
      if (s == 1 / 0) {
        n = "5e" + e;
      } else {
        n = s.toExponential();
        n = n.slice(0, n.indexOf("e") + 1) + e;
      }
      r = new Ctor(n);
    } else {
      r = new Ctor(s.toString());
    }
    sd = (e = Ctor.precision) + 3;
    for (; ; ) {
      t = r;
      r = t.plus(divide(x, t, sd + 2, 1)).times(0.5);
      if (digitsToString(t.d).slice(0, sd) === (n = digitsToString(r.d)).slice(0, sd)) {
        n = n.slice(sd - 3, sd + 1);
        if (n == "9999" || !rep && n == "4999") {
          if (!rep) {
            finalise(t, e + 1, 0);
            if (t.times(t).eq(x)) {
              r = t;
              break;
            }
          }
          sd += 4;
          rep = 1;
        } else {
          if (!+n || !+n.slice(1) && n.charAt(0) == "5") {
            finalise(r, e + 1, 1);
            m = !r.times(r).eq(x);
          }
          break;
        }
      }
    }
    external = true;
    return finalise(r, e, Ctor.rounding, m);
  };
  P.tangent = P.tan = function() {
    var pr, rm, x = this, Ctor = x.constructor;
    if (!x.isFinite()) return new Ctor(NaN);
    if (x.isZero()) return new Ctor(x);
    pr = Ctor.precision;
    rm = Ctor.rounding;
    Ctor.precision = pr + 10;
    Ctor.rounding = 1;
    x = x.sin();
    x.s = 1;
    x = divide(x, new Ctor(1).minus(x.times(x)).sqrt(), pr + 10, 0);
    Ctor.precision = pr;
    Ctor.rounding = rm;
    return finalise(quadrant == 2 || quadrant == 4 ? x.neg() : x, pr, rm, true);
  };
  P.times = P.mul = function(y) {
    var carry, e, i, k, r, rL, t, xdL, ydL, x = this, Ctor = x.constructor, xd = x.d, yd = (y = new Ctor(y)).d;
    y.s *= x.s;
    if (!xd || !xd[0] || !yd || !yd[0]) {
      return new Ctor(!y.s || xd && !xd[0] && !yd || yd && !yd[0] && !xd ? NaN : !xd || !yd ? y.s / 0 : y.s * 0);
    }
    e = mathfloor(x.e / LOG_BASE) + mathfloor(y.e / LOG_BASE);
    xdL = xd.length;
    ydL = yd.length;
    if (xdL < ydL) {
      r = xd;
      xd = yd;
      yd = r;
      rL = xdL;
      xdL = ydL;
      ydL = rL;
    }
    r = [];
    rL = xdL + ydL;
    for (i = rL; i--; ) r.push(0);
    for (i = ydL; --i >= 0; ) {
      carry = 0;
      for (k = xdL + i; k > i; ) {
        t = r[k] + yd[i] * xd[k - i - 1] + carry;
        r[k--] = t % BASE | 0;
        carry = t / BASE | 0;
      }
      r[k] = (r[k] + carry) % BASE | 0;
    }
    for (; !r[--rL]; ) r.pop();
    if (carry) ++e;
    else r.shift();
    y.d = r;
    y.e = getBase10Exponent(r, e);
    return external ? finalise(y, Ctor.precision, Ctor.rounding) : y;
  };
  P.toBinary = function(sd, rm) {
    return toStringBinary(this, 2, sd, rm);
  };
  P.toDecimalPlaces = P.toDP = function(dp, rm) {
    var x = this, Ctor = x.constructor;
    x = new Ctor(x);
    if (dp === void 0) return x;
    checkInt32(dp, 0, MAX_DIGITS);
    if (rm === void 0) rm = Ctor.rounding;
    else checkInt32(rm, 0, 8);
    return finalise(x, dp + x.e + 1, rm);
  };
  P.toExponential = function(dp, rm) {
    var str, x = this, Ctor = x.constructor;
    if (dp === void 0) {
      str = finiteToString(x, true);
    } else {
      checkInt32(dp, 0, MAX_DIGITS);
      if (rm === void 0) rm = Ctor.rounding;
      else checkInt32(rm, 0, 8);
      x = finalise(new Ctor(x), dp + 1, rm);
      str = finiteToString(x, true, dp + 1);
    }
    return x.isNeg() && !x.isZero() ? "-" + str : str;
  };
  P.toFixed = function(dp, rm) {
    var str, y, x = this, Ctor = x.constructor;
    if (dp === void 0) {
      str = finiteToString(x);
    } else {
      checkInt32(dp, 0, MAX_DIGITS);
      if (rm === void 0) rm = Ctor.rounding;
      else checkInt32(rm, 0, 8);
      y = finalise(new Ctor(x), dp + x.e + 1, rm);
      str = finiteToString(y, false, dp + y.e + 1);
    }
    return x.isNeg() && !x.isZero() ? "-" + str : str;
  };
  P.toFraction = function(maxD) {
    var d, d0, d1, d2, e, k, n, n0, n1, pr, q, r, x = this, xd = x.d, Ctor = x.constructor;
    if (!xd) return new Ctor(x);
    n1 = d0 = new Ctor(1);
    d1 = n0 = new Ctor(0);
    d = new Ctor(d1);
    e = d.e = getPrecision(xd) - x.e - 1;
    k = e % LOG_BASE;
    d.d[0] = mathpow(10, k < 0 ? LOG_BASE + k : k);
    if (maxD == null) {
      maxD = e > 0 ? d : n1;
    } else {
      n = new Ctor(maxD);
      if (!n.isInt() || n.lt(n1)) throw Error(invalidArgument + n);
      maxD = n.gt(d) ? e > 0 ? d : n1 : n;
    }
    external = false;
    n = new Ctor(digitsToString(xd));
    pr = Ctor.precision;
    Ctor.precision = e = xd.length * LOG_BASE * 2;
    for (; ; ) {
      q = divide(n, d, 0, 1, 1);
      d2 = d0.plus(q.times(d1));
      if (d2.cmp(maxD) == 1) break;
      d0 = d1;
      d1 = d2;
      d2 = n1;
      n1 = n0.plus(q.times(d2));
      n0 = d2;
      d2 = d;
      d = n.minus(q.times(d2));
      n = d2;
    }
    d2 = divide(maxD.minus(d0), d1, 0, 1, 1);
    n0 = n0.plus(d2.times(n1));
    d0 = d0.plus(d2.times(d1));
    n0.s = n1.s = x.s;
    r = divide(n1, d1, e, 1).minus(x).abs().cmp(divide(n0, d0, e, 1).minus(x).abs()) < 1 ? [n1, d1] : [n0, d0];
    Ctor.precision = pr;
    external = true;
    return r;
  };
  P.toHexadecimal = P.toHex = function(sd, rm) {
    return toStringBinary(this, 16, sd, rm);
  };
  P.toNearest = function(y, rm) {
    var x = this, Ctor = x.constructor;
    x = new Ctor(x);
    if (y == null) {
      if (!x.d) return x;
      y = new Ctor(1);
      rm = Ctor.rounding;
    } else {
      y = new Ctor(y);
      if (rm === void 0) {
        rm = Ctor.rounding;
      } else {
        checkInt32(rm, 0, 8);
      }
      if (!x.d) return y.s ? x : y;
      if (!y.d) {
        if (y.s) y.s = x.s;
        return y;
      }
    }
    if (y.d[0]) {
      external = false;
      x = divide(x, y, 0, rm, 1).times(y);
      external = true;
      finalise(x);
    } else {
      y.s = x.s;
      x = y;
    }
    return x;
  };
  P.toNumber = function() {
    return +this;
  };
  P.toOctal = function(sd, rm) {
    return toStringBinary(this, 8, sd, rm);
  };
  P.toPower = P.pow = function(y) {
    var e, k, pr, r, rm, s, x = this, Ctor = x.constructor, yn = +(y = new Ctor(y));
    if (!x.d || !y.d || !x.d[0] || !y.d[0]) return new Ctor(mathpow(+x, yn));
    x = new Ctor(x);
    if (x.eq(1)) return x;
    pr = Ctor.precision;
    rm = Ctor.rounding;
    if (y.eq(1)) return finalise(x, pr, rm);
    e = mathfloor(y.e / LOG_BASE);
    if (e >= y.d.length - 1 && (k = yn < 0 ? -yn : yn) <= MAX_SAFE_INTEGER) {
      r = intPow(Ctor, x, k, pr);
      return y.s < 0 ? new Ctor(1).div(r) : finalise(r, pr, rm);
    }
    s = x.s;
    if (s < 0) {
      if (e < y.d.length - 1) return new Ctor(NaN);
      if ((y.d[e] & 1) == 0) s = 1;
      if (x.e == 0 && x.d[0] == 1 && x.d.length == 1) {
        x.s = s;
        return x;
      }
    }
    k = mathpow(+x, yn);
    e = k == 0 || !isFinite(k) ? mathfloor(yn * (Math.log("0." + digitsToString(x.d)) / Math.LN10 + x.e + 1)) : new Ctor(k + "").e;
    if (e > Ctor.maxE + 1 || e < Ctor.minE - 1) return new Ctor(e > 0 ? s / 0 : 0);
    external = false;
    Ctor.rounding = x.s = 1;
    k = Math.min(12, (e + "").length);
    r = naturalExponential(y.times(naturalLogarithm(x, pr + k)), pr);
    if (r.d) {
      r = finalise(r, pr + 5, 1);
      if (checkRoundingDigits(r.d, pr, rm)) {
        e = pr + 10;
        r = finalise(naturalExponential(y.times(naturalLogarithm(x, e + k)), e), e + 5, 1);
        if (+digitsToString(r.d).slice(pr + 1, pr + 15) + 1 == 1e14) {
          r = finalise(r, pr + 1, 0);
        }
      }
    }
    r.s = s;
    external = true;
    Ctor.rounding = rm;
    return finalise(r, pr, rm);
  };
  P.toPrecision = function(sd, rm) {
    var str, x = this, Ctor = x.constructor;
    if (sd === void 0) {
      str = finiteToString(x, x.e <= Ctor.toExpNeg || x.e >= Ctor.toExpPos);
    } else {
      checkInt32(sd, 1, MAX_DIGITS);
      if (rm === void 0) rm = Ctor.rounding;
      else checkInt32(rm, 0, 8);
      x = finalise(new Ctor(x), sd, rm);
      str = finiteToString(x, sd <= x.e || x.e <= Ctor.toExpNeg, sd);
    }
    return x.isNeg() && !x.isZero() ? "-" + str : str;
  };
  P.toSignificantDigits = P.toSD = function(sd, rm) {
    var x = this, Ctor = x.constructor;
    if (sd === void 0) {
      sd = Ctor.precision;
      rm = Ctor.rounding;
    } else {
      checkInt32(sd, 1, MAX_DIGITS);
      if (rm === void 0) rm = Ctor.rounding;
      else checkInt32(rm, 0, 8);
    }
    return finalise(new Ctor(x), sd, rm);
  };
  P.toString = function() {
    var x = this, Ctor = x.constructor, str = finiteToString(x, x.e <= Ctor.toExpNeg || x.e >= Ctor.toExpPos);
    return x.isNeg() && !x.isZero() ? "-" + str : str;
  };
  P.truncated = P.trunc = function() {
    return finalise(new this.constructor(this), this.e + 1, 1);
  };
  P.valueOf = P.toJSON = function() {
    var x = this, Ctor = x.constructor, str = finiteToString(x, x.e <= Ctor.toExpNeg || x.e >= Ctor.toExpPos);
    return x.isNeg() ? "-" + str : str;
  };
  function digitsToString(d) {
    var i, k, ws, indexOfLastWord = d.length - 1, str = "", w = d[0];
    if (indexOfLastWord > 0) {
      str += w;
      for (i = 1; i < indexOfLastWord; i++) {
        ws = d[i] + "";
        k = LOG_BASE - ws.length;
        if (k) str += getZeroString(k);
        str += ws;
      }
      w = d[i];
      ws = w + "";
      k = LOG_BASE - ws.length;
      if (k) str += getZeroString(k);
    } else if (w === 0) {
      return "0";
    }
    for (; w % 10 === 0; ) w /= 10;
    return str + w;
  }
  function checkInt32(i, min2, max2) {
    if (i !== ~~i || i < min2 || i > max2) {
      throw Error(invalidArgument + i);
    }
  }
  function checkRoundingDigits(d, i, rm, repeating) {
    var di, k, r, rd;
    for (k = d[0]; k >= 10; k /= 10) --i;
    if (--i < 0) {
      i += LOG_BASE;
      di = 0;
    } else {
      di = Math.ceil((i + 1) / LOG_BASE);
      i %= LOG_BASE;
    }
    k = mathpow(10, LOG_BASE - i);
    rd = d[di] % k | 0;
    if (repeating == null) {
      if (i < 3) {
        if (i == 0) rd = rd / 100 | 0;
        else if (i == 1) rd = rd / 10 | 0;
        r = rm < 4 && rd == 99999 || rm > 3 && rd == 49999 || rd == 5e4 || rd == 0;
      } else {
        r = (rm < 4 && rd + 1 == k || rm > 3 && rd + 1 == k / 2) && (d[di + 1] / k / 100 | 0) == mathpow(10, i - 2) - 1 || (rd == k / 2 || rd == 0) && (d[di + 1] / k / 100 | 0) == 0;
      }
    } else {
      if (i < 4) {
        if (i == 0) rd = rd / 1e3 | 0;
        else if (i == 1) rd = rd / 100 | 0;
        else if (i == 2) rd = rd / 10 | 0;
        r = (repeating || rm < 4) && rd == 9999 || !repeating && rm > 3 && rd == 4999;
      } else {
        r = ((repeating || rm < 4) && rd + 1 == k || !repeating && rm > 3 && rd + 1 == k / 2) && (d[di + 1] / k / 1e3 | 0) == mathpow(10, i - 3) - 1;
      }
    }
    return r;
  }
  function convertBase(str, baseIn, baseOut) {
    var j, arr = [0], arrL, i = 0, strL = str.length;
    for (; i < strL; ) {
      for (arrL = arr.length; arrL--; ) arr[arrL] *= baseIn;
      arr[0] += NUMERALS.indexOf(str.charAt(i++));
      for (j = 0; j < arr.length; j++) {
        if (arr[j] > baseOut - 1) {
          if (arr[j + 1] === void 0) arr[j + 1] = 0;
          arr[j + 1] += arr[j] / baseOut | 0;
          arr[j] %= baseOut;
        }
      }
    }
    return arr.reverse();
  }
  function cosine(Ctor, x) {
    var k, len, y;
    if (x.isZero()) return x;
    len = x.d.length;
    if (len < 32) {
      k = Math.ceil(len / 3);
      y = (1 / tinyPow(4, k)).toString();
    } else {
      k = 16;
      y = "2.3283064365386962890625e-10";
    }
    Ctor.precision += k;
    x = taylorSeries(Ctor, 1, x.times(y), new Ctor(1));
    for (var i = k; i--; ) {
      var cos2x = x.times(x);
      x = cos2x.times(cos2x).minus(cos2x).times(8).plus(1);
    }
    Ctor.precision -= k;
    return x;
  }
  var divide = /* @__PURE__ */ (function() {
    function multiplyInteger(x, k, base) {
      var temp, carry = 0, i = x.length;
      for (x = x.slice(); i--; ) {
        temp = x[i] * k + carry;
        x[i] = temp % base | 0;
        carry = temp / base | 0;
      }
      if (carry) x.unshift(carry);
      return x;
    }
    function compare(a, b, aL, bL) {
      var i, r;
      if (aL != bL) {
        r = aL > bL ? 1 : -1;
      } else {
        for (i = r = 0; i < aL; i++) {
          if (a[i] != b[i]) {
            r = a[i] > b[i] ? 1 : -1;
            break;
          }
        }
      }
      return r;
    }
    function subtract(a, b, aL, base) {
      var i = 0;
      for (; aL--; ) {
        a[aL] -= i;
        i = a[aL] < b[aL] ? 1 : 0;
        a[aL] = i * base + a[aL] - b[aL];
      }
      for (; !a[0] && a.length > 1; ) a.shift();
    }
    return function(x, y, pr, rm, dp, base) {
      var cmp, e, i, k, logBase, more, prod, prodL, q, qd, rem, remL, rem0, sd, t, xi, xL, yd0, yL, yz, Ctor = x.constructor, sign2 = x.s == y.s ? 1 : -1, xd = x.d, yd = y.d;
      if (!xd || !xd[0] || !yd || !yd[0]) {
        return new Ctor(
          // Return NaN if either NaN, or both Infinity or 0.
          !x.s || !y.s || (xd ? yd && xd[0] == yd[0] : !yd) ? NaN : (
            // Return ±0 if x is 0 or y is ±Infinity, or return ±Infinity as y is 0.
            xd && xd[0] == 0 || !yd ? sign2 * 0 : sign2 / 0
          )
        );
      }
      if (base) {
        logBase = 1;
        e = x.e - y.e;
      } else {
        base = BASE;
        logBase = LOG_BASE;
        e = mathfloor(x.e / logBase) - mathfloor(y.e / logBase);
      }
      yL = yd.length;
      xL = xd.length;
      q = new Ctor(sign2);
      qd = q.d = [];
      for (i = 0; yd[i] == (xd[i] || 0); i++) ;
      if (yd[i] > (xd[i] || 0)) e--;
      if (pr == null) {
        sd = pr = Ctor.precision;
        rm = Ctor.rounding;
      } else if (dp) {
        sd = pr + (x.e - y.e) + 1;
      } else {
        sd = pr;
      }
      if (sd < 0) {
        qd.push(1);
        more = true;
      } else {
        sd = sd / logBase + 2 | 0;
        i = 0;
        if (yL == 1) {
          k = 0;
          yd = yd[0];
          sd++;
          for (; (i < xL || k) && sd--; i++) {
            t = k * base + (xd[i] || 0);
            qd[i] = t / yd | 0;
            k = t % yd | 0;
          }
          more = k || i < xL;
        } else {
          k = base / (yd[0] + 1) | 0;
          if (k > 1) {
            yd = multiplyInteger(yd, k, base);
            xd = multiplyInteger(xd, k, base);
            yL = yd.length;
            xL = xd.length;
          }
          xi = yL;
          rem = xd.slice(0, yL);
          remL = rem.length;
          for (; remL < yL; ) rem[remL++] = 0;
          yz = yd.slice();
          yz.unshift(0);
          yd0 = yd[0];
          if (yd[1] >= base / 2) ++yd0;
          do {
            k = 0;
            cmp = compare(yd, rem, yL, remL);
            if (cmp < 0) {
              rem0 = rem[0];
              if (yL != remL) rem0 = rem0 * base + (rem[1] || 0);
              k = rem0 / yd0 | 0;
              if (k > 1) {
                if (k >= base) k = base - 1;
                prod = multiplyInteger(yd, k, base);
                prodL = prod.length;
                remL = rem.length;
                cmp = compare(prod, rem, prodL, remL);
                if (cmp == 1) {
                  k--;
                  subtract(prod, yL < prodL ? yz : yd, prodL, base);
                }
              } else {
                if (k == 0) cmp = k = 1;
                prod = yd.slice();
              }
              prodL = prod.length;
              if (prodL < remL) prod.unshift(0);
              subtract(rem, prod, remL, base);
              if (cmp == -1) {
                remL = rem.length;
                cmp = compare(yd, rem, yL, remL);
                if (cmp < 1) {
                  k++;
                  subtract(rem, yL < remL ? yz : yd, remL, base);
                }
              }
              remL = rem.length;
            } else if (cmp === 0) {
              k++;
              rem = [0];
            }
            qd[i++] = k;
            if (cmp && rem[0]) {
              rem[remL++] = xd[xi] || 0;
            } else {
              rem = [xd[xi]];
              remL = 1;
            }
          } while ((xi++ < xL || rem[0] !== void 0) && sd--);
          more = rem[0] !== void 0;
        }
        if (!qd[0]) qd.shift();
      }
      if (logBase == 1) {
        q.e = e;
        inexact = more;
      } else {
        for (i = 1, k = qd[0]; k >= 10; k /= 10) i++;
        q.e = i + e * logBase - 1;
        finalise(q, dp ? pr + q.e + 1 : pr, rm, more);
      }
      return q;
    };
  })();
  function finalise(x, sd, rm, isTruncated) {
    var digits, i, j, k, rd, roundUp, w, xd, xdi, Ctor = x.constructor;
    out: if (sd != null) {
      xd = x.d;
      if (!xd) return x;
      for (digits = 1, k = xd[0]; k >= 10; k /= 10) digits++;
      i = sd - digits;
      if (i < 0) {
        i += LOG_BASE;
        j = sd;
        w = xd[xdi = 0];
        rd = w / mathpow(10, digits - j - 1) % 10 | 0;
      } else {
        xdi = Math.ceil((i + 1) / LOG_BASE);
        k = xd.length;
        if (xdi >= k) {
          if (isTruncated) {
            for (; k++ <= xdi; ) xd.push(0);
            w = rd = 0;
            digits = 1;
            i %= LOG_BASE;
            j = i - LOG_BASE + 1;
          } else {
            break out;
          }
        } else {
          w = k = xd[xdi];
          for (digits = 1; k >= 10; k /= 10) digits++;
          i %= LOG_BASE;
          j = i - LOG_BASE + digits;
          rd = j < 0 ? 0 : w / mathpow(10, digits - j - 1) % 10 | 0;
        }
      }
      isTruncated = isTruncated || sd < 0 || xd[xdi + 1] !== void 0 || (j < 0 ? w : w % mathpow(10, digits - j - 1));
      roundUp = rm < 4 ? (rd || isTruncated) && (rm == 0 || rm == (x.s < 0 ? 3 : 2)) : rd > 5 || rd == 5 && (rm == 4 || isTruncated || rm == 6 && // Check whether the digit to the left of the rounding digit is odd.
      (i > 0 ? j > 0 ? w / mathpow(10, digits - j) : 0 : xd[xdi - 1]) % 10 & 1 || rm == (x.s < 0 ? 8 : 7));
      if (sd < 1 || !xd[0]) {
        xd.length = 0;
        if (roundUp) {
          sd -= x.e + 1;
          xd[0] = mathpow(10, (LOG_BASE - sd % LOG_BASE) % LOG_BASE);
          x.e = -sd || 0;
        } else {
          xd[0] = x.e = 0;
        }
        return x;
      }
      if (i == 0) {
        xd.length = xdi;
        k = 1;
        xdi--;
      } else {
        xd.length = xdi + 1;
        k = mathpow(10, LOG_BASE - i);
        xd[xdi] = j > 0 ? (w / mathpow(10, digits - j) % mathpow(10, j) | 0) * k : 0;
      }
      if (roundUp) {
        for (; ; ) {
          if (xdi == 0) {
            for (i = 1, j = xd[0]; j >= 10; j /= 10) i++;
            j = xd[0] += k;
            for (k = 1; j >= 10; j /= 10) k++;
            if (i != k) {
              x.e++;
              if (xd[0] == BASE) xd[0] = 1;
            }
            break;
          } else {
            xd[xdi] += k;
            if (xd[xdi] != BASE) break;
            xd[xdi--] = 0;
            k = 1;
          }
        }
      }
      for (i = xd.length; xd[--i] === 0; ) xd.pop();
    }
    if (external) {
      if (x.e > Ctor.maxE) {
        x.d = null;
        x.e = NaN;
      } else if (x.e < Ctor.minE) {
        x.e = 0;
        x.d = [0];
      }
    }
    return x;
  }
  function finiteToString(x, isExp, sd) {
    if (!x.isFinite()) return nonFiniteToString(x);
    var k, e = x.e, str = digitsToString(x.d), len = str.length;
    if (isExp) {
      if (sd && (k = sd - len) > 0) {
        str = str.charAt(0) + "." + str.slice(1) + getZeroString(k);
      } else if (len > 1) {
        str = str.charAt(0) + "." + str.slice(1);
      }
      str = str + (x.e < 0 ? "e" : "e+") + x.e;
    } else if (e < 0) {
      str = "0." + getZeroString(-e - 1) + str;
      if (sd && (k = sd - len) > 0) str += getZeroString(k);
    } else if (e >= len) {
      str += getZeroString(e + 1 - len);
      if (sd && (k = sd - e - 1) > 0) str = str + "." + getZeroString(k);
    } else {
      if ((k = e + 1) < len) str = str.slice(0, k) + "." + str.slice(k);
      if (sd && (k = sd - len) > 0) {
        if (e + 1 === len) str += ".";
        str += getZeroString(k);
      }
    }
    return str;
  }
  function getBase10Exponent(digits, e) {
    var w = digits[0];
    for (e *= LOG_BASE; w >= 10; w /= 10) e++;
    return e;
  }
  function getLn10(Ctor, sd, pr) {
    if (sd > LN10_PRECISION) {
      external = true;
      if (pr) Ctor.precision = pr;
      throw Error(precisionLimitExceeded);
    }
    return finalise(new Ctor(LN10), sd, 1, true);
  }
  function getPi(Ctor, sd, rm) {
    if (sd > PI_PRECISION) throw Error(precisionLimitExceeded);
    return finalise(new Ctor(PI), sd, rm, true);
  }
  function getPrecision(digits) {
    var w = digits.length - 1, len = w * LOG_BASE + 1;
    w = digits[w];
    if (w) {
      for (; w % 10 == 0; w /= 10) len--;
      for (w = digits[0]; w >= 10; w /= 10) len++;
    }
    return len;
  }
  function getZeroString(k) {
    var zs = "";
    for (; k--; ) zs += "0";
    return zs;
  }
  function intPow(Ctor, x, n, pr) {
    var isTruncated, r = new Ctor(1), k = Math.ceil(pr / LOG_BASE + 4);
    external = false;
    for (; ; ) {
      if (n % 2) {
        r = r.times(x);
        if (truncate(r.d, k)) isTruncated = true;
      }
      n = mathfloor(n / 2);
      if (n === 0) {
        n = r.d.length - 1;
        if (isTruncated && r.d[n] === 0) ++r.d[n];
        break;
      }
      x = x.times(x);
      truncate(x.d, k);
    }
    external = true;
    return r;
  }
  function isOdd(n) {
    return n.d[n.d.length - 1] & 1;
  }
  function maxOrMin(Ctor, args, n) {
    var k, y, x = new Ctor(args[0]), i = 0;
    for (; ++i < args.length; ) {
      y = new Ctor(args[i]);
      if (!y.s) {
        x = y;
        break;
      }
      k = x.cmp(y);
      if (k === n || k === 0 && x.s === n) {
        x = y;
      }
    }
    return x;
  }
  function naturalExponential(x, sd) {
    var denominator, guard, j, pow2, sum2, t, wpr, rep = 0, i = 0, k = 0, Ctor = x.constructor, rm = Ctor.rounding, pr = Ctor.precision;
    if (!x.d || !x.d[0] || x.e > 17) {
      return new Ctor(x.d ? !x.d[0] ? 1 : x.s < 0 ? 0 : 1 / 0 : x.s ? x.s < 0 ? 0 : x : 0 / 0);
    }
    if (sd == null) {
      external = false;
      wpr = pr;
    } else {
      wpr = sd;
    }
    t = new Ctor(0.03125);
    while (x.e > -2) {
      x = x.times(t);
      k += 5;
    }
    guard = Math.log(mathpow(2, k)) / Math.LN10 * 2 + 5 | 0;
    wpr += guard;
    denominator = pow2 = sum2 = new Ctor(1);
    Ctor.precision = wpr;
    for (; ; ) {
      pow2 = finalise(pow2.times(x), wpr, 1);
      denominator = denominator.times(++i);
      t = sum2.plus(divide(pow2, denominator, wpr, 1));
      if (digitsToString(t.d).slice(0, wpr) === digitsToString(sum2.d).slice(0, wpr)) {
        j = k;
        while (j--) sum2 = finalise(sum2.times(sum2), wpr, 1);
        if (sd == null) {
          if (rep < 3 && checkRoundingDigits(sum2.d, wpr - guard, rm, rep)) {
            Ctor.precision = wpr += 10;
            denominator = pow2 = t = new Ctor(1);
            i = 0;
            rep++;
          } else {
            return finalise(sum2, Ctor.precision = pr, rm, external = true);
          }
        } else {
          Ctor.precision = pr;
          return sum2;
        }
      }
      sum2 = t;
    }
  }
  function naturalLogarithm(y, sd) {
    var c, c0, denominator, e, numerator, rep, sum2, t, wpr, x1, x2, n = 1, guard = 10, x = y, xd = x.d, Ctor = x.constructor, rm = Ctor.rounding, pr = Ctor.precision;
    if (x.s < 0 || !xd || !xd[0] || !x.e && xd[0] == 1 && xd.length == 1) {
      return new Ctor(xd && !xd[0] ? -1 / 0 : x.s != 1 ? NaN : xd ? 0 : x);
    }
    if (sd == null) {
      external = false;
      wpr = pr;
    } else {
      wpr = sd;
    }
    Ctor.precision = wpr += guard;
    c = digitsToString(xd);
    c0 = c.charAt(0);
    if (Math.abs(e = x.e) < 15e14) {
      while (c0 < 7 && c0 != 1 || c0 == 1 && c.charAt(1) > 3) {
        x = x.times(y);
        c = digitsToString(x.d);
        c0 = c.charAt(0);
        n++;
      }
      e = x.e;
      if (c0 > 1) {
        x = new Ctor("0." + c);
        e++;
      } else {
        x = new Ctor(c0 + "." + c.slice(1));
      }
    } else {
      t = getLn10(Ctor, wpr + 2, pr).times(e + "");
      x = naturalLogarithm(new Ctor(c0 + "." + c.slice(1)), wpr - guard).plus(t);
      Ctor.precision = pr;
      return sd == null ? finalise(x, pr, rm, external = true) : x;
    }
    x1 = x;
    sum2 = numerator = x = divide(x.minus(1), x.plus(1), wpr, 1);
    x2 = finalise(x.times(x), wpr, 1);
    denominator = 3;
    for (; ; ) {
      numerator = finalise(numerator.times(x2), wpr, 1);
      t = sum2.plus(divide(numerator, new Ctor(denominator), wpr, 1));
      if (digitsToString(t.d).slice(0, wpr) === digitsToString(sum2.d).slice(0, wpr)) {
        sum2 = sum2.times(2);
        if (e !== 0) sum2 = sum2.plus(getLn10(Ctor, wpr + 2, pr).times(e + ""));
        sum2 = divide(sum2, new Ctor(n), wpr, 1);
        if (sd == null) {
          if (checkRoundingDigits(sum2.d, wpr - guard, rm, rep)) {
            Ctor.precision = wpr += guard;
            t = numerator = x = divide(x1.minus(1), x1.plus(1), wpr, 1);
            x2 = finalise(x.times(x), wpr, 1);
            denominator = rep = 1;
          } else {
            return finalise(sum2, Ctor.precision = pr, rm, external = true);
          }
        } else {
          Ctor.precision = pr;
          return sum2;
        }
      }
      sum2 = t;
      denominator += 2;
    }
  }
  function nonFiniteToString(x) {
    return String(x.s * x.s / 0);
  }
  function parseDecimal(x, str) {
    var e, i, len;
    if ((e = str.indexOf(".")) > -1) str = str.replace(".", "");
    if ((i = str.search(/e/i)) > 0) {
      if (e < 0) e = i;
      e += +str.slice(i + 1);
      str = str.substring(0, i);
    } else if (e < 0) {
      e = str.length;
    }
    for (i = 0; str.charCodeAt(i) === 48; i++) ;
    for (len = str.length; str.charCodeAt(len - 1) === 48; --len) ;
    str = str.slice(i, len);
    if (str) {
      len -= i;
      x.e = e = e - i - 1;
      x.d = [];
      i = (e + 1) % LOG_BASE;
      if (e < 0) i += LOG_BASE;
      if (i < len) {
        if (i) x.d.push(+str.slice(0, i));
        for (len -= LOG_BASE; i < len; ) x.d.push(+str.slice(i, i += LOG_BASE));
        str = str.slice(i);
        i = LOG_BASE - str.length;
      } else {
        i -= len;
      }
      for (; i--; ) str += "0";
      x.d.push(+str);
      if (external) {
        if (x.e > x.constructor.maxE) {
          x.d = null;
          x.e = NaN;
        } else if (x.e < x.constructor.minE) {
          x.e = 0;
          x.d = [0];
        }
      }
    } else {
      x.e = 0;
      x.d = [0];
    }
    return x;
  }
  function parseOther(x, str) {
    var base, Ctor, divisor, i, isFloat, len, p, xd, xe;
    if (str.indexOf("_") > -1) {
      str = str.replace(/(\d)_(?=\d)/g, "$1");
      if (isDecimal.test(str)) return parseDecimal(x, str);
    } else if (str === "Infinity" || str === "NaN") {
      if (!+str) x.s = NaN;
      x.e = NaN;
      x.d = null;
      return x;
    }
    if (isHex.test(str)) {
      base = 16;
      str = str.toLowerCase();
    } else if (isBinary.test(str)) {
      base = 2;
    } else if (isOctal.test(str)) {
      base = 8;
    } else {
      throw Error(invalidArgument + str);
    }
    i = str.search(/p/i);
    if (i > 0) {
      p = +str.slice(i + 1);
      str = str.substring(2, i);
    } else {
      str = str.slice(2);
    }
    i = str.indexOf(".");
    isFloat = i >= 0;
    Ctor = x.constructor;
    if (isFloat) {
      str = str.replace(".", "");
      len = str.length;
      i = len - i;
      divisor = intPow(Ctor, new Ctor(base), i, i * 2);
    }
    xd = convertBase(str, base, BASE);
    xe = xd.length - 1;
    for (i = xe; xd[i] === 0; --i) xd.pop();
    if (i < 0) return new Ctor(x.s * 0);
    x.e = getBase10Exponent(xd, xe);
    x.d = xd;
    external = false;
    if (isFloat) x = divide(x, divisor, len * 4);
    if (p) x = x.times(Math.abs(p) < 54 ? mathpow(2, p) : Decimal.pow(2, p));
    external = true;
    return x;
  }
  function sine(Ctor, x) {
    var k, len = x.d.length;
    if (len < 3) {
      return x.isZero() ? x : taylorSeries(Ctor, 2, x, x);
    }
    k = 1.4 * Math.sqrt(len);
    k = k > 16 ? 16 : k | 0;
    x = x.times(1 / tinyPow(5, k));
    x = taylorSeries(Ctor, 2, x, x);
    var sin2_x, d5 = new Ctor(5), d16 = new Ctor(16), d20 = new Ctor(20);
    for (; k--; ) {
      sin2_x = x.times(x);
      x = x.times(d5.plus(sin2_x.times(d16.times(sin2_x).minus(d20))));
    }
    return x;
  }
  function taylorSeries(Ctor, n, x, y, isHyperbolic) {
    var j, t, u, x2, i = 1, pr = Ctor.precision, k = Math.ceil(pr / LOG_BASE);
    external = false;
    x2 = x.times(x);
    u = new Ctor(y);
    for (; ; ) {
      t = divide(u.times(x2), new Ctor(n++ * n++), pr, 1);
      u = isHyperbolic ? y.plus(t) : y.minus(t);
      y = divide(t.times(x2), new Ctor(n++ * n++), pr, 1);
      t = u.plus(y);
      if (t.d[k] !== void 0) {
        for (j = k; t.d[j] === u.d[j] && j--; ) ;
        if (j == -1) break;
      }
      j = u;
      u = y;
      y = t;
      t = j;
      i++;
    }
    external = true;
    t.d.length = k + 1;
    return t;
  }
  function tinyPow(b, e) {
    var n = b;
    while (--e) n *= b;
    return n;
  }
  function toLessThanHalfPi(Ctor, x) {
    var t, isNeg = x.s < 0, pi = getPi(Ctor, Ctor.precision, 1), halfPi = pi.times(0.5);
    x = x.abs();
    if (x.lte(halfPi)) {
      quadrant = isNeg ? 4 : 1;
      return x;
    }
    t = x.divToInt(pi);
    if (t.isZero()) {
      quadrant = isNeg ? 3 : 2;
    } else {
      x = x.minus(t.times(pi));
      if (x.lte(halfPi)) {
        quadrant = isOdd(t) ? isNeg ? 2 : 3 : isNeg ? 4 : 1;
        return x;
      }
      quadrant = isOdd(t) ? isNeg ? 1 : 4 : isNeg ? 3 : 2;
    }
    return x.minus(pi).abs();
  }
  function toStringBinary(x, baseOut, sd, rm) {
    var base, e, i, k, len, roundUp, str, xd, y, Ctor = x.constructor, isExp = sd !== void 0;
    if (isExp) {
      checkInt32(sd, 1, MAX_DIGITS);
      if (rm === void 0) rm = Ctor.rounding;
      else checkInt32(rm, 0, 8);
    } else {
      sd = Ctor.precision;
      rm = Ctor.rounding;
    }
    if (!x.isFinite()) {
      str = nonFiniteToString(x);
    } else {
      str = finiteToString(x);
      i = str.indexOf(".");
      if (isExp) {
        base = 2;
        if (baseOut == 16) {
          sd = sd * 4 - 3;
        } else if (baseOut == 8) {
          sd = sd * 3 - 2;
        }
      } else {
        base = baseOut;
      }
      if (i >= 0) {
        str = str.replace(".", "");
        y = new Ctor(1);
        y.e = str.length - i;
        y.d = convertBase(finiteToString(y), 10, base);
        y.e = y.d.length;
      }
      xd = convertBase(str, 10, base);
      e = len = xd.length;
      for (; xd[--len] == 0; ) xd.pop();
      if (!xd[0]) {
        str = isExp ? "0p+0" : "0";
      } else {
        if (i < 0) {
          e--;
        } else {
          x = new Ctor(x);
          x.d = xd;
          x.e = e;
          x = divide(x, y, sd, rm, 0, base);
          xd = x.d;
          e = x.e;
          roundUp = inexact;
        }
        i = xd[sd];
        k = base / 2;
        roundUp = roundUp || xd[sd + 1] !== void 0;
        roundUp = rm < 4 ? (i !== void 0 || roundUp) && (rm === 0 || rm === (x.s < 0 ? 3 : 2)) : i > k || i === k && (rm === 4 || roundUp || rm === 6 && xd[sd - 1] & 1 || rm === (x.s < 0 ? 8 : 7));
        xd.length = sd;
        if (roundUp) {
          for (; ++xd[--sd] > base - 1; ) {
            xd[sd] = 0;
            if (!sd) {
              ++e;
              xd.unshift(1);
            }
          }
        }
        for (len = xd.length; !xd[len - 1]; --len) ;
        for (i = 0, str = ""; i < len; i++) str += NUMERALS.charAt(xd[i]);
        if (isExp) {
          if (len > 1) {
            if (baseOut == 16 || baseOut == 8) {
              i = baseOut == 16 ? 4 : 3;
              for (--len; len % i; len++) str += "0";
              xd = convertBase(str, base, baseOut);
              for (len = xd.length; !xd[len - 1]; --len) ;
              for (i = 1, str = "1."; i < len; i++) str += NUMERALS.charAt(xd[i]);
            } else {
              str = str.charAt(0) + "." + str.slice(1);
            }
          }
          str = str + (e < 0 ? "p" : "p+") + e;
        } else if (e < 0) {
          for (; ++e; ) str = "0" + str;
          str = "0." + str;
        } else {
          if (++e > len) for (e -= len; e--; ) str += "0";
          else if (e < len) str = str.slice(0, e) + "." + str.slice(e);
        }
      }
      str = (baseOut == 16 ? "0x" : baseOut == 2 ? "0b" : baseOut == 8 ? "0o" : "") + str;
    }
    return x.s < 0 ? "-" + str : str;
  }
  function truncate(arr, len) {
    if (arr.length > len) {
      arr.length = len;
      return true;
    }
  }
  function abs(x) {
    return new this(x).abs();
  }
  function acos(x) {
    return new this(x).acos();
  }
  function acosh(x) {
    return new this(x).acosh();
  }
  function add(x, y) {
    return new this(x).plus(y);
  }
  function asin(x) {
    return new this(x).asin();
  }
  function asinh(x) {
    return new this(x).asinh();
  }
  function atan(x) {
    return new this(x).atan();
  }
  function atanh(x) {
    return new this(x).atanh();
  }
  function atan2(y, x) {
    y = new this(y);
    x = new this(x);
    var r, pr = this.precision, rm = this.rounding, wpr = pr + 4;
    if (!y.s || !x.s) {
      r = new this(NaN);
    } else if (!y.d && !x.d) {
      r = getPi(this, wpr, 1).times(x.s > 0 ? 0.25 : 0.75);
      r.s = y.s;
    } else if (!x.d || y.isZero()) {
      r = x.s < 0 ? getPi(this, pr, rm) : new this(0);
      r.s = y.s;
    } else if (!y.d || x.isZero()) {
      r = getPi(this, wpr, 1).times(0.5);
      r.s = y.s;
    } else if (x.s < 0) {
      this.precision = wpr;
      this.rounding = 1;
      r = this.atan(divide(y, x, wpr, 1));
      x = getPi(this, wpr, 1);
      this.precision = pr;
      this.rounding = rm;
      r = y.s < 0 ? r.minus(x) : r.plus(x);
    } else {
      r = this.atan(divide(y, x, wpr, 1));
    }
    return r;
  }
  function cbrt(x) {
    return new this(x).cbrt();
  }
  function ceil(x) {
    return finalise(x = new this(x), x.e + 1, 2);
  }
  function clamp(x, min2, max2) {
    return new this(x).clamp(min2, max2);
  }
  function config(obj) {
    if (!obj || typeof obj !== "object") throw Error(decimalError + "Object expected");
    var i, p, v, useDefaults = obj.defaults === true, ps = [
      "precision",
      1,
      MAX_DIGITS,
      "rounding",
      0,
      8,
      "toExpNeg",
      -EXP_LIMIT,
      0,
      "toExpPos",
      0,
      EXP_LIMIT,
      "maxE",
      0,
      EXP_LIMIT,
      "minE",
      -EXP_LIMIT,
      0,
      "modulo",
      0,
      9
    ];
    for (i = 0; i < ps.length; i += 3) {
      if (p = ps[i], useDefaults) this[p] = DEFAULTS[p];
      if ((v = obj[p]) !== void 0) {
        if (mathfloor(v) === v && v >= ps[i + 1] && v <= ps[i + 2]) this[p] = v;
        else throw Error(invalidArgument + p + ": " + v);
      }
    }
    if (p = "crypto", useDefaults) this[p] = DEFAULTS[p];
    if ((v = obj[p]) !== void 0) {
      if (v === true || v === false || v === 0 || v === 1) {
        if (v) {
          if (typeof crypto != "undefined" && crypto && (crypto.getRandomValues || crypto.randomBytes)) {
            this[p] = true;
          } else {
            throw Error(cryptoUnavailable);
          }
        } else {
          this[p] = false;
        }
      } else {
        throw Error(invalidArgument + p + ": " + v);
      }
    }
    return this;
  }
  function cos(x) {
    return new this(x).cos();
  }
  function cosh(x) {
    return new this(x).cosh();
  }
  function clone(obj) {
    var i, p, ps;
    function Decimal2(v) {
      var e, i2, t, x = this;
      if (!(x instanceof Decimal2)) return new Decimal2(v);
      x.constructor = Decimal2;
      if (isDecimalInstance(v)) {
        x.s = v.s;
        if (external) {
          if (!v.d || v.e > Decimal2.maxE) {
            x.e = NaN;
            x.d = null;
          } else if (v.e < Decimal2.minE) {
            x.e = 0;
            x.d = [0];
          } else {
            x.e = v.e;
            x.d = v.d.slice();
          }
        } else {
          x.e = v.e;
          x.d = v.d ? v.d.slice() : v.d;
        }
        return;
      }
      t = typeof v;
      if (t === "number") {
        if (v === 0) {
          x.s = 1 / v < 0 ? -1 : 1;
          x.e = 0;
          x.d = [0];
          return;
        }
        if (v < 0) {
          v = -v;
          x.s = -1;
        } else {
          x.s = 1;
        }
        if (v === ~~v && v < 1e7) {
          for (e = 0, i2 = v; i2 >= 10; i2 /= 10) e++;
          if (external) {
            if (e > Decimal2.maxE) {
              x.e = NaN;
              x.d = null;
            } else if (e < Decimal2.minE) {
              x.e = 0;
              x.d = [0];
            } else {
              x.e = e;
              x.d = [v];
            }
          } else {
            x.e = e;
            x.d = [v];
          }
          return;
        }
        if (v * 0 !== 0) {
          if (!v) x.s = NaN;
          x.e = NaN;
          x.d = null;
          return;
        }
        return parseDecimal(x, v.toString());
      }
      if (t === "string") {
        if ((i2 = v.charCodeAt(0)) === 45) {
          v = v.slice(1);
          x.s = -1;
        } else {
          if (i2 === 43) v = v.slice(1);
          x.s = 1;
        }
        return isDecimal.test(v) ? parseDecimal(x, v) : parseOther(x, v);
      }
      if (t === "bigint") {
        if (v < 0) {
          v = -v;
          x.s = -1;
        } else {
          x.s = 1;
        }
        return parseDecimal(x, v.toString());
      }
      throw Error(invalidArgument + v);
    }
    Decimal2.prototype = P;
    Decimal2.ROUND_UP = 0;
    Decimal2.ROUND_DOWN = 1;
    Decimal2.ROUND_CEIL = 2;
    Decimal2.ROUND_FLOOR = 3;
    Decimal2.ROUND_HALF_UP = 4;
    Decimal2.ROUND_HALF_DOWN = 5;
    Decimal2.ROUND_HALF_EVEN = 6;
    Decimal2.ROUND_HALF_CEIL = 7;
    Decimal2.ROUND_HALF_FLOOR = 8;
    Decimal2.EUCLID = 9;
    Decimal2.config = Decimal2.set = config;
    Decimal2.clone = clone;
    Decimal2.isDecimal = isDecimalInstance;
    Decimal2.abs = abs;
    Decimal2.acos = acos;
    Decimal2.acosh = acosh;
    Decimal2.add = add;
    Decimal2.asin = asin;
    Decimal2.asinh = asinh;
    Decimal2.atan = atan;
    Decimal2.atanh = atanh;
    Decimal2.atan2 = atan2;
    Decimal2.cbrt = cbrt;
    Decimal2.ceil = ceil;
    Decimal2.clamp = clamp;
    Decimal2.cos = cos;
    Decimal2.cosh = cosh;
    Decimal2.div = div;
    Decimal2.exp = exp;
    Decimal2.floor = floor;
    Decimal2.hypot = hypot;
    Decimal2.ln = ln;
    Decimal2.log = log;
    Decimal2.log10 = log10;
    Decimal2.log2 = log2;
    Decimal2.max = max;
    Decimal2.min = min;
    Decimal2.mod = mod;
    Decimal2.mul = mul;
    Decimal2.pow = pow;
    Decimal2.random = random;
    Decimal2.round = round;
    Decimal2.sign = sign;
    Decimal2.sin = sin;
    Decimal2.sinh = sinh;
    Decimal2.sqrt = sqrt;
    Decimal2.sub = sub;
    Decimal2.sum = sum;
    Decimal2.tan = tan;
    Decimal2.tanh = tanh;
    Decimal2.trunc = trunc;
    if (obj === void 0) obj = {};
    if (obj) {
      if (obj.defaults !== true) {
        ps = ["precision", "rounding", "toExpNeg", "toExpPos", "maxE", "minE", "modulo", "crypto"];
        for (i = 0; i < ps.length; ) if (!obj.hasOwnProperty(p = ps[i++])) obj[p] = this[p];
      }
    }
    Decimal2.config(obj);
    return Decimal2;
  }
  function div(x, y) {
    return new this(x).div(y);
  }
  function exp(x) {
    return new this(x).exp();
  }
  function floor(x) {
    return finalise(x = new this(x), x.e + 1, 3);
  }
  function hypot() {
    var i, n, t = new this(0);
    external = false;
    for (i = 0; i < arguments.length; ) {
      n = new this(arguments[i++]);
      if (!n.d) {
        if (n.s) {
          external = true;
          return new this(1 / 0);
        }
        t = n;
      } else if (t.d) {
        t = t.plus(n.times(n));
      }
    }
    external = true;
    return t.sqrt();
  }
  function isDecimalInstance(obj) {
    return obj instanceof Decimal || obj && obj.toStringTag === tag || false;
  }
  function ln(x) {
    return new this(x).ln();
  }
  function log(x, y) {
    return new this(x).log(y);
  }
  function log2(x) {
    return new this(x).log(2);
  }
  function log10(x) {
    return new this(x).log(10);
  }
  function max() {
    return maxOrMin(this, arguments, -1);
  }
  function min() {
    return maxOrMin(this, arguments, 1);
  }
  function mod(x, y) {
    return new this(x).mod(y);
  }
  function mul(x, y) {
    return new this(x).mul(y);
  }
  function pow(x, y) {
    return new this(x).pow(y);
  }
  function random(sd) {
    var d, e, k, n, i = 0, r = new this(1), rd = [];
    if (sd === void 0) sd = this.precision;
    else checkInt32(sd, 1, MAX_DIGITS);
    k = Math.ceil(sd / LOG_BASE);
    if (!this.crypto) {
      for (; i < k; ) rd[i++] = Math.random() * 1e7 | 0;
    } else if (crypto.getRandomValues) {
      d = crypto.getRandomValues(new Uint32Array(k));
      for (; i < k; ) {
        n = d[i];
        if (n >= 429e7) {
          d[i] = crypto.getRandomValues(new Uint32Array(1))[0];
        } else {
          rd[i++] = n % 1e7;
        }
      }
    } else if (crypto.randomBytes) {
      d = crypto.randomBytes(k *= 4);
      for (; i < k; ) {
        n = d[i] + (d[i + 1] << 8) + (d[i + 2] << 16) + ((d[i + 3] & 127) << 24);
        if (n >= 214e7) {
          crypto.randomBytes(4).copy(d, i);
        } else {
          rd.push(n % 1e7);
          i += 4;
        }
      }
      i = k / 4;
    } else {
      throw Error(cryptoUnavailable);
    }
    k = rd[--i];
    sd %= LOG_BASE;
    if (k && sd) {
      n = mathpow(10, LOG_BASE - sd);
      rd[i] = (k / n | 0) * n;
    }
    for (; rd[i] === 0; i--) rd.pop();
    if (i < 0) {
      e = 0;
      rd = [0];
    } else {
      e = -1;
      for (; rd[0] === 0; e -= LOG_BASE) rd.shift();
      for (k = 1, n = rd[0]; n >= 10; n /= 10) k++;
      if (k < LOG_BASE) e -= LOG_BASE - k;
    }
    r.e = e;
    r.d = rd;
    return r;
  }
  function round(x) {
    return finalise(x = new this(x), x.e + 1, this.rounding);
  }
  function sign(x) {
    x = new this(x);
    return x.d ? x.d[0] ? x.s : 0 * x.s : x.s || NaN;
  }
  function sin(x) {
    return new this(x).sin();
  }
  function sinh(x) {
    return new this(x).sinh();
  }
  function sqrt(x) {
    return new this(x).sqrt();
  }
  function sub(x, y) {
    return new this(x).sub(y);
  }
  function sum() {
    var i = 0, args = arguments, x = new this(args[i]);
    external = false;
    for (; x.s && ++i < args.length; ) x = x.plus(args[i]);
    external = true;
    return finalise(x, this.precision, this.rounding);
  }
  function tan(x) {
    return new this(x).tan();
  }
  function tanh(x) {
    return new this(x).tanh();
  }
  function trunc(x) {
    return finalise(x = new this(x), x.e + 1, 1);
  }
  P[Symbol.for("nodejs.util.inspect.custom")] = P.toString;
  P[Symbol.toStringTag] = "Decimal";
  var Decimal = P.constructor = clone(DEFAULTS);
  LN10 = new Decimal(LN10);
  PI = new Decimal(PI);
  var decimal_default = Decimal;

  // ../../packages/pricing/src/decimal.ts
  var PricingDecimal = decimal_default.clone({
    precision: 40,
    rounding: decimal_default.ROUND_HALF_UP,
    toExpNeg: -40,
    toExpPos: 40
  });
  var PricingError = class extends Error {
    constructor(code, message) {
      super(message);
      __publicField(this, "code");
      this.name = "PricingError";
      this.code = code;
    }
  };
  var DECIMAL_RE = /^[+-]?(\d+(\.\d*)?|\.\d+)$/;
  function dec(value, field = "value") {
    if (value instanceof PricingDecimal) {
      if (!value.isFinite()) throw new PricingError("invalid_number", `${field} must be finite`);
      return value;
    }
    if (typeof value === "number") {
      if (!Number.isFinite(value))
        throw new PricingError("invalid_number", `${field} must be finite, got ${value}`);
      return new PricingDecimal(value);
    }
    const t = value.trim();
    if (!DECIMAL_RE.test(t))
      throw new PricingError("invalid_number", `${field} is not a decimal number: "${value}"`);
    return new PricingDecimal(t);
  }
  function nonNegative(value, field) {
    const d = dec(value, field);
    if (d.isNegative() && !d.isZero())
      throw new PricingError("negative_value", `${field} must be >= 0`);
    return d;
  }
  function rate(value, field, max2 = 10) {
    const d = nonNegative(value, field);
    if (d.gt(dec(max2)))
      throw new PricingError("rate_out_of_range", `${field} must be <= ${String(max2)}`);
    return d;
  }
  var ZERO = new PricingDecimal(0);
  var ONE = new PricingDecimal(1);
  var CURRENCY_MINOR_DIGITS = Object.freeze({
    USD: 2,
    CAD: 2,
    EUR: 2,
    GBP: 2,
    AUD: 2,
    MXN: 2,
    JPY: 0
  });
  function minorDigits(currency) {
    const d = CURRENCY_MINOR_DIGITS[currency];
    if (d === void 0)
      throw new PricingError("unsupported_currency", `unsupported currency ${String(currency)}`);
    return d;
  }
  function roundMoney(value, currency) {
    return dec(value).toDecimalPlaces(minorDigits(currency), PricingDecimal.ROUND_HALF_UP);
  }
  function money(value, currency) {
    const digits = minorDigits(currency);
    const d = dec(value);
    if (!d.toDecimalPlaces(digits).eq(d)) {
      throw new PricingError(
        "unrounded_money",
        `${d.toString()} is not rounded to ${digits} decimals`
      );
    }
    return {
      currency,
      minor: BigInt(d.times(new PricingDecimal(10).pow(digits)).toFixed(0)),
      amount: d.toFixed(digits)
    };
  }
  var RoundingLog = class {
    constructor(currency) {
      this.currency = currency;
      __publicField(this, "records", []);
    }
    round(stage, label, exact) {
      const rounded = roundMoney(exact, this.currency);
      this.records.push({
        stage,
        label,
        exact: exact.toString(),
        rounded: rounded.toFixed(minorDigits(this.currency))
      });
      return rounded;
    }
  };
  function fmt(value, decimals = 4) {
    return value.toDecimalPlaces(decimals, PricingDecimal.ROUND_HALF_UP).toFixed(decimals);
  }

  // ../../packages/pricing/src/units.ts
  var FT = new PricingDecimal("0.3048");
  var IN = new PricingDecimal("0.0254");
  var YD = new PricingDecimal("0.9144");
  var FACTORS = {
    m: { dim: "length", si: new PricingDecimal(1) },
    cm: { dim: "length", si: new PricingDecimal("0.01") },
    mm: { dim: "length", si: new PricingDecimal("0.001") },
    ft: { dim: "length", si: FT },
    in: { dim: "length", si: IN },
    yd: { dim: "length", si: YD },
    m2: { dim: "area", si: new PricingDecimal(1) },
    ft2: { dim: "area", si: FT.pow(2) },
    yd2: { dim: "area", si: YD.pow(2) },
    in2: { dim: "area", si: IN.pow(2) },
    square: { dim: "area", si: FT.pow(2).times(100) },
    m3: { dim: "volume", si: new PricingDecimal(1) },
    ft3: { dim: "volume", si: FT.pow(3) },
    yd3: { dim: "volume", si: YD.pow(3) }
  };
  function unitDimension(unit) {
    const f = FACTORS[unit];
    if (!f) throw new PricingError("unknown_unit", `unknown unit ${String(unit)}`);
    return f.dim;
  }
  function convertQuantity(value, from, to) {
    if (unitDimension(from) !== unitDimension(to)) {
      throw new PricingError("dimension_mismatch", `cannot convert ${from} to ${to}`);
    }
    const v = dec(value);
    return from === to ? v : v.times(FACTORS[from].si).div(FACTORS[to].si);
  }
  var FT2_PER_SQUARE = new PricingDecimal(100);

  // ../../packages/pricing/src/engine.ts
  var SCENARIOS = ["low", "base", "high"];
  function isBounded(v) {
    return typeof v === "object" && v !== null && !(v instanceof PricingDecimal) && "base" in v;
  }
  function scenarioValue(v, s, field) {
    if (!isBounded(v)) return dec(v, field);
    const low = dec(v.low, `${field}.low`);
    const base = dec(v.base, `${field}.base`);
    const high = dec(v.high, `${field}.high`);
    if (low.gt(base) || base.gt(high))
      throw new PricingError("invalid_bounds", `${field}: need low <= base <= high`);
    return s === "low" ? low : s === "high" ? high : base;
  }
  function triple(f) {
    return { low: f("low"), base: f("base"), high: f("high") };
  }
  function policyRates(policy) {
    const overhead = rate(policy.overheadRate ?? 0, "overheadRate");
    const contingency = rate(policy.contingencyRate ?? 0, "contingencyRate");
    const p = policy.price;
    if (p.markupRate !== void 0 && p.marginRate !== void 0) {
      throw new PricingError("markup_and_margin", "apply EITHER markup OR target margin, never both");
    }
    if (p.method === "target_margin") {
      const m = rate(p.marginRate, "marginRate");
      if (m.gte(ONE)) throw new PricingError("rate_out_of_range", "marginRate must be < 1");
    } else if (p.method === "markup") {
      rate(p.markupRate, "markupRate", 100);
    } else if (p.method !== "cost_plus_none") {
      throw new PricingError(
        "invalid_policy",
        `unknown price method ${String(p.method)}`
      );
    }
    return { overhead, contingency };
  }
  function priceEstimate(input) {
    const { policy } = input;
    const currency = policy.currency;
    const { overhead: overheadRate, contingency: contingencyRate } = policyRates(policy);
    const flags = [];
    const codes = /* @__PURE__ */ new Set();
    for (const l of input.lines) {
      if (codes.has(l.code))
        throw new PricingError("duplicate_line", `duplicate line code ${l.code}`);
      codes.add(l.code);
    }
    const logs = triple(() => new RoundingLog(currency));
    let pending = false;
    let bounded = false;
    const lines = input.lines.map((l) => {
      const unresolved = l.quantity === null || l.unitRate === null;
      if (unresolved) {
        const reason = l.unresolvedReason ?? (l.quantity === null ? "quantity unknown" : "no approved unit rate");
        if (l.critical) {
          pending = true;
          flags.push({
            code: "unpriced_critical_component",
            message: `${l.code}: ${reason}; pending review (never $0)`
          });
        } else {
          flags.push({
            code: "unresolved_optional_line",
            message: `${l.code}: ${reason}; excluded from totals`
          });
        }
        return {
          code: l.code,
          description: l.description,
          category: l.category,
          unit: l.unit,
          status: "unresolved",
          critical: l.critical,
          quantity: l.quantity === null ? null : triple(
            (s) => scenarioValue(l.quantity, s, `${l.code}.quantity`).toString()
          ),
          unitRate: l.unitRate === null ? null : triple(
            (s) => scenarioValue(l.unitRate, s, `${l.code}.unitRate`).toString()
          ),
          extended: null,
          sourceRevision: l.sourceRevision,
          formulaVersion: l.formulaVersion,
          confidence: l.confidence,
          formula: l.formula,
          unresolvedReason: reason
        };
      }
      if (isBounded(l.quantity) || isBounded(l.unitRate)) bounded = true;
      const q = triple((s) => scenarioValue(l.quantity, s, `${l.code}.quantity`));
      const r = triple((s) => scenarioValue(l.unitRate, s, `${l.code}.unitRate`));
      for (const s of SCENARIOS) {
        if (q[s].isNegative() && !q[s].isZero())
          throw new PricingError("negative_value", `${l.code}: quantity must be >= 0`);
      }
      const ext = triple(
        (s) => money(logs[s].round("line_extension", l.code, q[s].times(r[s])), currency)
      );
      return {
        code: l.code,
        description: l.description,
        category: l.category,
        unit: l.unit,
        status: "priced",
        critical: l.critical,
        quantity: triple((s) => q[s].toString()),
        unitRate: triple((s) => r[s].toString()),
        extended: ext,
        sourceRevision: l.sourceRevision,
        formulaVersion: l.formulaVersion,
        confidence: l.confidence,
        formula: l.formula,
        unresolvedReason: null
      };
    });
    for (const sc of input.surcharges ?? []) if (isBounded(sc.rate)) bounded = true;
    const rangeDrivers = computeRangeDrivers(input);
    if (pending) {
      return {
        engineVersion: ENGINE_VERSION,
        trade: input.trade,
        recipe: input.recipe,
        policyRevision: policy.revision,
        currency,
        status: "pending_review",
        firm: false,
        lines,
        scenarios: null,
        rangeDrivers,
        flags
      };
    }
    const scenarios = triple(
      (s) => breakdown(s, lines, input, overheadRate, contingencyRate, logs[s], flags)
    );
    if (bounded) {
      flags.push({
        code: "planning_range",
        message: "bounded assumptions remain: show the low/base/high planning range, withhold a firm total"
      });
      const threshold = policy.uncertaintyThreshold;
      const base = new PricingDecimal(scenarios.base.total.amount);
      if (threshold !== void 0 && threshold !== null && base.gt(0)) {
        const width = new PricingDecimal(scenarios.high.total.amount).minus(scenarios.low.total.amount).div(base);
        if (width.gt(rate(threshold, "uncertaintyThreshold"))) {
          flags.push({
            code: "site_verification_required",
            message: `range width ${fmt(width.times(100), 1)}% exceeds policy threshold`
          });
        }
      }
    }
    return {
      engineVersion: ENGINE_VERSION,
      trade: input.trade,
      recipe: input.recipe,
      policyRevision: policy.revision,
      currency,
      status: "priced",
      firm: !bounded,
      lines,
      scenarios,
      rangeDrivers,
      flags: dedupeFlags(flags)
    };
  }
  function dedupeFlags(flags) {
    const seen = /* @__PURE__ */ new Set();
    return flags.filter((f) => {
      const k = `${f.code}:${f.message}`;
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  }
  function breakdown(s, lines, input, overheadRate, contingencyRate, log3, flags) {
    const { policy } = input;
    const currency = policy.currency;
    const m = (d) => money(d, currency);
    const priced = lines.filter((l) => l.status === "priced");
    const ext = (l) => new PricingDecimal(l.extended[s].amount);
    const surcharges = (input.surcharges ?? []).map((sc) => {
      const r = scenarioValue(sc.rate, s, `${sc.code}.rate`);
      rate(r, `${sc.code}.rate`);
      const targets = priced.filter((l) => !sc.appliesTo || sc.appliesTo.includes(l.code));
      const base = targets.reduce((acc, l) => acc.plus(ext(l)), ZERO);
      return { code: sc.code, amount: log3.round("surcharge", sc.code, base.times(r)) };
    });
    const direct = priced.reduce((acc, l) => acc.plus(ext(l)), ZERO).plus(surcharges.reduce((a, x) => a.plus(x.amount), ZERO));
    const overhead = log3.round("overhead", "overhead", direct.times(overheadRate));
    const contingency = log3.round(
      "contingency",
      "contingency",
      direct.plus(overhead).times(contingencyRate)
    );
    const basis = direct.plus(overhead).plus(contingency);
    let price;
    const p = policy.price;
    if (p.method === "markup")
      price = log3.round("price", "markup", basis.times(ONE.plus(dec(p.markupRate))));
    else if (p.method === "target_margin")
      price = log3.round("price", "target_margin", basis.div(ONE.minus(dec(p.marginRate))));
    else price = basis;
    let running = price;
    const discounts = (policy.discounts ?? []).map((d) => {
      const raw = d.kind === "percent" ? running.times(rate(d.value, `${d.code}.value`, 1)) : dec(d.value, `${d.code}.value`);
      if (raw.isNegative())
        throw new PricingError("negative_value", `${d.code}: discount must be >= 0`);
      const amount = PricingDecimal.min(log3.round("discount", d.code, raw), running);
      running = running.minus(amount);
      return { code: d.code, amount: m(amount), reason: d.reason };
    });
    let minAdj = ZERO;
    if (policy.minimumCharge !== void 0 && policy.minimumCharge !== null) {
      const min2 = log3.round(
        "minimum_charge",
        "minimum_charge",
        dec(policy.minimumCharge, "minimumCharge")
      );
      if (running.lt(min2)) {
        minAdj = min2.minus(running);
        running = min2;
        flags.push({
          code: "minimum_charge_applied",
          message: "pre-tax subtotal raised to the minimum job charge"
        });
      }
    }
    const subtotal = running;
    let tax = ZERO;
    const t = policy.tax;
    if (t) {
      const taxRate = rate(t.rate, "tax.rate", 1);
      if (t.exemption) {
        flags.push({
          code: "tax_exempt",
          message: `tax exempt: certificate ${t.exemption.certificateId}`
        });
      } else {
        let taxable = subtotal;
        if (t.basis === "taxable_share") {
          const all = priced.reduce((acc, l) => acc.plus(ext(l)), ZERO);
          const tx = priced.filter((l) => input.lines.find((x) => x.code === l.code)?.taxable !== false).reduce((acc, l) => acc.plus(ext(l)), ZERO);
          taxable = all.isZero() ? ZERO : subtotal.times(tx).div(all);
        }
        tax = log3.round("tax", t.jurisdiction ?? "tax", taxable.times(taxRate));
      }
    }
    const grossMargin = subtotal.isZero() ? null : subtotal.minus(basis).div(subtotal);
    const markupOnCost = basis.isZero() ? null : subtotal.minus(basis).div(basis);
    if (policy.marginFloor !== void 0 && policy.marginFloor !== null && grossMargin !== null) {
      if (grossMargin.lt(rate(policy.marginFloor, "marginFloor", 1))) {
        flags.push({
          code: "below_margin_floor",
          message: `realized gross margin ${fmt(grossMargin.times(100), 2)}% is below the floor; approval required`
        });
      }
    }
    return {
      directCost: m(direct),
      surcharges: surcharges.map((x) => ({ code: x.code, amount: m(x.amount) })),
      overhead: m(overhead),
      contingency: m(contingency),
      costBasis: m(basis),
      priceBeforeDiscounts: m(price),
      discounts,
      minimumChargeAdjustment: m(minAdj),
      subtotal: m(subtotal),
      tax: m(tax),
      total: m(subtotal.plus(tax)),
      grossMargin: grossMargin === null ? null : fmt(grossMargin, 4),
      markupOnCost: markupOnCost === null ? null : fmt(markupOnCost, 4),
      rounding: [...log3.records]
    };
  }
  function computeRangeDrivers(input) {
    const drivers = [];
    for (const l of input.lines) {
      if (l.quantity === null || l.unitRate === null) continue;
      for (const which of ["quantity", "unitRate"]) {
        const v = l[which];
        if (!isBounded(v)) continue;
        const other = which === "quantity" ? l.unitRate : l.quantity;
        const ob = scenarioValue(other, "base", l.code);
        const swing = scenarioValue(v, "high", l.code).minus(scenarioValue(v, "low", l.code)).times(ob);
        drivers.push({
          swing,
          d: {
            lineCode: l.code,
            input: which,
            reason: v.reason,
            directCostSwing: swing.toDecimalPlaces(2).toFixed(2)
          }
        });
      }
    }
    for (const sc of input.surcharges ?? []) {
      if (!isBounded(sc.rate)) continue;
      const base = input.lines.filter(
        (l) => l.quantity !== null && l.unitRate !== null && (!sc.appliesTo || sc.appliesTo.includes(l.code))
      ).reduce(
        (a, l) => a.plus(
          scenarioValue(l.quantity, "base", l.code).times(
            scenarioValue(l.unitRate, "base", l.code)
          )
        ),
        ZERO
      );
      const swing = scenarioValue(sc.rate, "high", sc.code).minus(scenarioValue(sc.rate, "low", sc.code)).times(base);
      drivers.push({
        swing,
        d: {
          lineCode: sc.code,
          input: "surcharge",
          reason: sc.rate.reason,
          directCostSwing: swing.toDecimalPlaces(2).toFixed(2)
        }
      });
    }
    return drivers.sort((a, b) => b.swing.comparedTo(a.swing) || (a.d.lineCode < b.d.lineCode ? -1 : 1)).map((x) => x.d);
  }

  // ../../packages/pricing/src/roof.ts
  var ROOF_EDGE_TYPES = [
    "eave",
    "rake",
    "ridge",
    "hip",
    "valley",
    "flashing",
    "step_flashing",
    "perimeter",
    "unclassified"
  ];
  function slopeFactor(p) {
    const rise = nonNegative(p.rise, "pitch.rise");
    const run = dec(p.run, "pitch.run");
    if (run.lte(0)) throw new PricingError("invalid_pitch", "pitch.run must be > 0");
    const r = rise.div(run);
    return ONE.plus(r.times(r)).sqrt();
  }
  function figures(plan, sloped) {
    const ft2 = sloped === null ? null : convertQuantity(sloped, "m2", "ft2");
    return {
      planM2: plan.toString(),
      slopedM2: sloped === null ? null : sloped.toString(),
      slopedFt2: ft2 === null ? null : ft2.toString(),
      squares: ft2 === null ? null : ft2.div(FT2_PER_SQUARE).toString()
    };
  }
  function roofTakeoff(input) {
    const excluded = new Set(input.excludedStructureIds ?? []);
    const ids = /* @__PURE__ */ new Set();
    const rows = input.facets.map((f) => {
      if (ids.has(f.id)) throw new PricingError("duplicate_facet", `duplicate facet ${f.id}`);
      ids.add(f.id);
      const plan = nonNegative(f.planAreaM2, `${f.id}.planAreaM2`);
      const factor = f.pitch === null ? null : slopeFactor(f.pitch);
      return {
        f,
        plan,
        factor,
        sloped: factor === null ? null : plan.times(factor),
        included: !excluded.has(f.structureId)
      };
    });
    const sum2 = (list) => ({
      plan: list.reduce((a, r) => a.plus(r.plan), ZERO),
      sloped: list.some((r) => r.sloped === null) ? null : list.reduce((a, r) => a.plus(r.sloped), ZERO)
    });
    const structures = {};
    for (const sid of [...new Set(rows.map((r) => r.f.structureId))].sort()) {
      const t = sum2(rows.filter((r) => r.f.structureId === sid));
      structures[sid] = figures(t.plan, t.sloped);
    }
    const prop = sum2(rows.filter((r) => r.included));
    const edgeLf = {};
    for (const t of ROOF_EDGE_TYPES) {
      const v = input.edgeLengthsM[t];
      edgeLf[t] = v === null ? null : convertQuantity(nonNegative(v ?? 0, `edge.${t}`), "m", "ft");
    }
    return {
      formulaVersion: ROOF_TAKEOFF_VERSION,
      facets: rows.map((r) => ({
        id: r.f.id,
        structureId: r.f.structureId,
        slopeFactor: r.factor === null ? null : r.factor.toString(),
        included: r.included,
        ...figures(r.plan, r.sloped)
      })),
      structures,
      property: figures(prop.plan, prop.sloped),
      slopedFt2: prop.sloped === null ? null : convertQuantity(prop.sloped, "m2", "ft2"),
      edgeLf
    };
  }
  function selectWaste(input) {
    const rec = input.recommendation?.status === "recommended" ? input.recommendation : null;
    if (input.override) {
      if (!input.override.reason.trim())
        throw new PricingError("override_reason_required", "waste override needs a reason");
      return {
        status: "selected",
        wasteRate: rate(input.override.wasteRate, "override.wasteRate", 1),
        source: "override",
        recommendedRate: rec ? rec.wasteRate : null,
        reason: input.override.reason,
        formulaVersion: ROOF_WASTE_VERSION
      };
    }
    if (rec) {
      return {
        status: "selected",
        wasteRate: dec(rec.wasteRate),
        source: "recommendation",
        recommendedRate: rec.wasteRate,
        reason: rec.reasonCodes.join(","),
        formulaVersion: ROOF_WASTE_VERSION
      };
    }
    return {
      status: "unresolved",
      reason: "no validated recommendation: a human-entered waste value with explanation is required",
      formulaVersion: ROOF_WASTE_VERSION
    };
  }
  var PACK_TOLERANCE = new PricingDecimal("1e-9");
  function orderPacks(exact) {
    const nearest = exact.toDecimalPlaces(0, PricingDecimal.ROUND_HALF_UP);
    if (exact.minus(nearest).abs().lte(PACK_TOLERANCE)) return nearest;
    return exact.toDecimalPlaces(0, PricingDecimal.ROUND_CEIL);
  }
  function materialTakeoff(takeoff, specs, waste2) {
    return specs.map((spec) => {
      const unit = spec.basis.kind === "sloped_area" ? "ft2" : spec.basis.kind === "edges" ? "lf" : "each";
      const unresolved = (reason, base2 = null) => ({
        code: spec.code,
        materialClass: spec.materialClass,
        status: "unresolved",
        baseQuantity: base2 === null ? null : base2.toString(),
        baseUnit: unit,
        wasteRate: null,
        quantityWithWaste: null,
        exactPacks: null,
        orderPacks: null,
        packUnit: spec.packUnit,
        sku: spec.sku ?? null,
        formula: `${spec.code}: unresolved (${reason})`,
        unresolvedReason: reason,
        formulaVersion: ROOF_TAKEOFF_VERSION
      });
      let base;
      let baseText;
      if (spec.basis.kind === "sloped_area") {
        base = takeoff.slopedFt2;
        baseText = "sloped roof area";
      } else if (spec.basis.kind === "edges") {
        const parts = spec.basis.edgeTypes.map((t) => takeoff.edgeLf[t]);
        base = parts.some((p) => p === null) ? null : parts.reduce((a, p) => a.plus(p), ZERO);
        baseText = spec.basis.edgeTypes.join(" + ");
      } else {
        base = spec.basis.count === null ? null : nonNegative(spec.basis.count, `${spec.code}.count`);
        baseText = "count";
      }
      if (base === null) return unresolved(`${baseText} unknown`);
      if (spec.coveragePerPack === null)
        return unresolved("coverage per pack unknown; no default brand dimensions substituted", base);
      const coverage = dec(spec.coveragePerPack, `${spec.code}.coveragePerPack`);
      if (coverage.lte(0))
        throw new PricingError("invalid_coverage", `${spec.code}: coverage must be > 0`);
      let w = ZERO;
      if (spec.basis.kind !== "count") {
        const sel = waste2[spec.materialClass];
        if (!sel || sel.status !== "selected")
          return unresolved(`waste for ${spec.materialClass} not selected`, base);
        w = sel.wasteRate;
      }
      const withWaste = base.times(ONE.plus(w));
      const exact = withWaste.div(coverage);
      const order = orderPacks(exact);
      return {
        code: spec.code,
        materialClass: spec.materialClass,
        status: "resolved",
        baseQuantity: base.toString(),
        baseUnit: unit,
        wasteRate: w.toString(),
        quantityWithWaste: withWaste.toString(),
        exactPacks: exact.toString(),
        orderPacks: order.toString(),
        packUnit: spec.packUnit,
        sku: spec.sku ?? null,
        formula: `${spec.code}: ${fmt(base)} ${unit} (${baseText}) x (1 + ${fmt(w.times(100), 2)}% waste) = ${fmt(withWaste)} ${unit} / ${fmt(coverage)} ${unit} per ${spec.packUnit} = ${fmt(exact)} ${spec.packUnit} -> order ${order.toString()} ${spec.packUnit}`,
        unresolvedReason: null,
        formulaVersion: ROOF_TAKEOFF_VERSION
      };
    });
  }
  function roofCostLines(takeoff, materials, specs, labor = []) {
    const lines = materials.map((m) => {
      const spec = specs.find((s) => s.code === m.code);
      if (!spec) throw new PricingError("unknown_material", `no spec for ${m.code}`);
      return {
        code: m.code,
        description: spec.description,
        category: "material",
        quantity: m.orderPacks,
        unit: m.packUnit,
        unitRate: spec.unitPrice,
        critical: spec.critical,
        taxable: true,
        sourceRevision: spec.priceSourceRevision,
        formulaVersion: m.formulaVersion,
        confidence: "medium",
        formula: m.formula,
        ...m.unresolvedReason ? { unresolvedReason: m.unresolvedReason } : {}
      };
    });
    const squares = takeoff.slopedFt2 === null ? null : takeoff.slopedFt2.div(FT2_PER_SQUARE);
    for (const l of labor) {
      lines.push({
        code: l.code,
        description: l.description,
        category: "labor",
        quantity: squares,
        unit: "square",
        unitRate: l.ratePerSquare,
        critical: true,
        taxable: false,
        sourceRevision: l.sourceRevision,
        formulaVersion: ROOF_TAKEOFF_VERSION,
        confidence: "medium",
        formula: squares === null ? `${l.code}: sloped area unknown` : `${l.code}: ${fmt(squares)} squares (sloped, no waste) x rate`,
        ...squares === null ? { unresolvedReason: "sloped area unknown (pitch missing)" } : {}
      });
    }
    return lines;
  }

  // ../../packages/pricing/src/curb.ts
  function dimTo(d, to, field) {
    if (d.state === "unknown") return { unknown: `${field}: ${d.reason}` };
    if (d.state === "known") {
      const v = convertQuantity(nonNegative(d.value, field), d.unit, to);
      return { low: v, base: v, high: v, reasons: [] };
    }
    const low = convertQuantity(nonNegative(d.low, `${field}.low`), d.unit, to);
    const base = convertQuantity(nonNegative(d.base, `${field}.base`), d.unit, to);
    const high = convertQuantity(nonNegative(d.high, `${field}.high`), d.unit, to);
    if (low.gt(base) || base.gt(high))
      throw new PricingError("invalid_bounds", `${field}: need low <= base <= high`);
    return { low, base, high, reasons: [`${field}: ${d.reason}`] };
  }
  function mulV(a, b) {
    if ("unknown" in a) return a;
    if ("unknown" in b) return b;
    return {
      low: a.low.times(b.low),
      base: a.base.times(b.base),
      high: a.high.times(b.high),
      reasons: [...a.reasons, ...b.reasons]
    };
  }
  function toQty(v, unit, formula) {
    if ("unknown" in v) return { state: "unknown", unit, reason: v.unknown, formula };
    if (v.low.eq(v.high)) return { state: "known", value: v.base, unit, formula };
    return {
      state: "bounded",
      low: v.low,
      base: v.base,
      high: v.high,
      unit,
      formula,
      reason: v.reasons.join("; ")
    };
  }
  function kv(v) {
    return { low: v, base: v, high: v, reasons: [] };
  }
  function curbQuantities(input) {
    if (!Number.isInteger(input.sawPasses) || input.sawPasses < 1)
      throw new PricingError("invalid_passes", "sawPasses must be an integer >= 1");
    if (input.segments.length === 0)
      throw new PricingError("no_segments", "at least one validated curb segment is required");
    const issues = [];
    const cutFt = input.segments.reduce(
      (a, s) => a.plus(convertQuantity(nonNegative(s.length, `${s.id}.length`), s.unit ?? "m", "ft")),
      ZERO
    );
    if (cutFt.isZero()) issues.push({ code: "zero_length", message: "total cut length is zero" });
    const cut = kv(cutFt);
    const passes = kv(new PricingDecimal(input.sawPasses));
    let depth = dimTo(input.cutDepth, "in", "cutDepth");
    if (!("unknown" in depth) && depth.low.isZero()) {
      issues.push({ code: "zero_depth", message: "cut depth of zero is not a cut; verify depth" });
      depth = { unknown: "cutDepth: zero depth is invalid" };
    }
    const passLen = mulV(cut, passes);
    const removalLen = input.removalLength ? dimTo(input.removalLength, "ft", "removalLength") : cut;
    const width = dimTo(input.removalWidth, "ft", "removalWidth");
    const section = dimTo(input.crossSection, "ft2", "crossSection");
    const volFt3 = mulV(section, removalLen);
    const volYd3 = "unknown" in volFt3 ? volFt3 : {
      ...volFt3,
      low: convertQuantity(volFt3.low, "ft3", "yd3"),
      base: convertQuantity(volFt3.base, "ft3", "yd3"),
      high: convertQuantity(volFt3.high, "ft3", "yd3")
    };
    const restLen = dimTo(input.restorationLength, "ft", "restorationLength");
    const restWidth = input.restorationWidth ? dimTo(input.restorationWidth, "ft", "restorationWidth") : { unknown: "restorationWidth: not provided" };
    return {
      formulaVersion: CURB_QUANTITY_VERSION,
      segmentCount: input.segments.length,
      cutLengthFt: toQty(
        cut,
        "ft",
        `sum of ${input.segments.length} piecewise segment lengths = ${fmt(cutFt)} ft`
      ),
      sawPassLengthFt: toQty(passLen, "ft", `${fmt(cutFt)} ft cut line x ${input.sawPasses} passes`),
      inchFeet: toQty(mulV(passLen, depth), "in-ft", "saw pass length (ft) x cut depth (in)"),
      cutDepthIn: toQty(depth, "in", "cut depth"),
      removalAreaFt2: toQty(mulV(removalLen, width), "ft2", "removal length x removal width"),
      removalVolumeFt3: toQty(volFt3, "ft3", "confirmed cross-section (ft2) x removal length (ft)"),
      removalVolumeYd3: toQty(
        volYd3,
        "yd3",
        "confirmed cross-section (ft2) x removal length (ft) / 27"
      ),
      restorationLengthFt: toQty(restLen, "ft", "restoration length"),
      restorationAreaFt2: toQty(
        mulV(restLen, restWidth),
        "ft2",
        "restoration length x restoration width"
      ),
      issues
    };
  }
  function qtyValue(q) {
    if (q.state === "known") return q.value;
    if (q.state === "bounded")
      return { low: q.low, base: q.base, high: q.high, reason: q.reason };
    return null;
  }
  function tieredAmount(quantity, tiers) {
    let check = ZERO;
    tiers.forEach((t, i) => {
      const cap = t.upTo === null ? null : dec(t.upTo, "tier.upTo");
      if (cap === null && i !== tiers.length - 1)
        throw new PricingError("invalid_tiers", "only the last tier may be unbounded");
      if (cap !== null && cap.lte(check))
        throw new PricingError("invalid_tiers", "tiers must have increasing bounds");
      if (cap !== null) check = cap;
    });
    let prev = ZERO;
    let total = ZERO;
    for (const t of tiers) {
      const cap = t.upTo === null ? null : dec(t.upTo, "tier.upTo");
      const top = cap === null ? quantity : PricingDecimal.min(quantity, cap);
      if (top.gt(prev)) total = total.plus(top.minus(prev).times(dec(t.rate, "tier.rate")));
      if (cap === null || quantity.lte(cap)) return total;
      prev = cap;
    }
    throw new PricingError("invalid_tiers", "last tier must be unbounded (upTo null)");
  }
  function curbCostLines(q, recipe, book) {
    const byCode = new Map(book.map((b) => [b.code, b]));
    const basisQty = (b, c) => {
      switch (b) {
        case "fixed":
          return {
            state: "known",
            value: nonNegative(c.fixedQuantity ?? 1, `${c.code}.fixedQuantity`),
            unit: "each",
            formula: "fixed item"
          };
        case "cut_length_ft":
          return q.cutLengthFt;
        case "saw_pass_length_ft":
          return q.sawPassLengthFt;
        case "inch_feet":
          return q.inchFeet;
        case "removal_area_ft2":
          return q.removalAreaFt2;
        case "removal_volume_yd3":
          return q.removalVolumeYd3;
        case "restoration_length_ft":
          return q.restorationLengthFt;
        case "restoration_area_ft2":
          return q.restorationAreaFt2;
        case "segment_count":
          return {
            state: "known",
            value: new PricingDecimal(q.segmentCount),
            unit: "each",
            formula: "segment count"
          };
        default: {
          const never = b;
          throw new PricingError("unknown_basis", `unknown basis ${String(never)}`);
        }
      }
    };
    return recipe.components.map((c) => {
      const qty = basisQty(c.basis, c);
      const item = byCode.get(c.priceItem);
      const quantity = qtyValue(qty);
      let unitRate = item ? item.rate : null;
      let formula = `${c.code}: ${qty.state === "known" ? fmt(qty.value) : qty.state === "bounded" ? `${fmt(qty.low)}-${fmt(qty.high)}` : "unknown"} ${qty.unit} (${qty.formula})`;
      if (c.tiers && quantity !== null && !isBounded(quantity)) {
        const qd = dec(quantity);
        unitRate = qd.isZero() ? dec(c.tiers[0]?.rate ?? 0) : tieredAmount(qd, c.tiers).div(qd);
        formula += " at graduated tier rates";
      } else if (unitRate !== null) {
        formula += ` x ${isBounded(unitRate) ? `${String(unitRate.low)}-${String(unitRate.high)}` : dec(unitRate).toString()} per ${item?.unit ?? qty.unit}`;
      }
      const reason = quantity === null ? qty.state === "unknown" ? qty.reason : "unknown" : unitRate === null ? `no approved rate for ${c.priceItem}` : void 0;
      return {
        code: c.code,
        description: c.description,
        category: c.category,
        quantity,
        unit: qty.unit,
        unitRate,
        critical: c.critical,
        taxable: c.taxable ?? true,
        sourceRevision: item?.revision ?? null,
        formulaVersion: `${CURB_RECIPE_VERSION}/${recipe.id}@${recipe.version}`,
        confidence: c.confidence ?? (qty.state === "known" ? "high" : "low"),
        formula,
        ...reason ? { unresolvedReason: reason } : {}
      };
    });
  }

  // src/calc.ts
  var EXAMPLE_PRICE_BOOK = [
    { code: "saw_lf", unit: "ft", rate: "20", revision: "synthetic-book-2026.1" },
    { code: "mob", unit: "each", rate: "400", revision: "synthetic-book-2026.1" },
    { code: "breakout_lf", unit: "ft", rate: "28", revision: "synthetic-book-2026.1" },
    { code: "disposal_load", unit: "each", rate: "220", revision: "synthetic-book-2026.1" },
    { code: "replace_lf", unit: "ft", rate: "95", revision: "synthetic-book-2026.1" },
    { code: "traffic", unit: "each", rate: "350", revision: "synthetic-book-2026.1" },
    { code: "permit", unit: "each", rate: "200", revision: "synthetic-book-2026.1" }
  ];
  var PAGE60_RECIPE = {
    id: "driveway-opening",
    version: "1.0.0",
    components: [
      {
        code: "cutting",
        description: "Saw cutting",
        category: "labor",
        basis: "cut_length_ft",
        priceItem: "saw_lf",
        critical: true
      },
      {
        code: "mobilization",
        description: "Mobilization",
        category: "fixed",
        basis: "fixed",
        priceItem: "mob",
        critical: true
      },
      {
        code: "breakout",
        description: "Breakout",
        category: "labor",
        basis: "cut_length_ft",
        priceItem: "breakout_lf",
        critical: true
      },
      {
        code: "disposal",
        description: "Haul-off and disposal",
        category: "disposal",
        basis: "fixed",
        priceItem: "disposal_load",
        critical: true
      },
      {
        code: "replacement",
        description: "Concrete replacement",
        category: "subcontract",
        basis: "restoration_length_ft",
        priceItem: "replace_lf",
        critical: true
      },
      {
        code: "traffic_control",
        description: "Traffic control",
        category: "traffic_control",
        basis: "fixed",
        priceItem: "traffic",
        critical: true
      },
      {
        code: "permit_allowance",
        description: "Permit allowance",
        category: "permit",
        basis: "fixed",
        priceItem: "permit",
        critical: true,
        taxable: false
      }
    ]
  };
  var EXAMPLE_MATERIALS = [
    {
      code: "shingles",
      description: "Architectural shingles",
      materialClass: "shingles",
      basis: { kind: "sloped_area" },
      coveragePerPack: "33.3333333333333333333",
      packUnit: "bundle",
      unitPrice: "42.50",
      priceSourceRevision: "example-cat-1 (synthetic)",
      critical: true
    },
    {
      code: "underlayment",
      description: "Synthetic underlayment",
      materialClass: "underlayment",
      basis: { kind: "sloped_area" },
      coveragePerPack: "1000",
      packUnit: "roll",
      unitPrice: "150",
      priceSourceRevision: "example-cat-1 (synthetic)",
      critical: true
    },
    {
      code: "ridge_cap",
      description: "Ridge cap",
      materialClass: "ridge_cap",
      basis: { kind: "edges", edgeTypes: ["ridge", "hip"] },
      coveragePerPack: "25",
      packUnit: "bundle",
      unitPrice: "70",
      priceSourceRevision: "example-cat-1 (synthetic)",
      critical: true
    }
  ];
  var EXAMPLE_LABOR = {
    code: "install_labor",
    description: "Tear-off and install",
    ratePerSquare: "95",
    sourceRevision: "example-labor-1 (synthetic)"
  };
  function waste(rate2) {
    return selectWaste({
      recommendation: null,
      override: { wasteRate: rate2, reason: "package default", by: "estimator" }
    });
  }
  function computeCurbExample(cutLengthFt = "18") {
    const quantities = curbQuantities({
      segments: [{ id: "s1", kind: "straight", length: cutLengthFt, unit: "ft" }],
      sawPasses: 2,
      cutDepth: { state: "known", value: "6", unit: "in" },
      removalWidth: { state: "known", value: "2", unit: "ft" },
      crossSection: { state: "known", value: "1.5", unit: "ft2" },
      restorationLength: { state: "known", value: cutLengthFt, unit: "ft" },
      restorationWidth: { state: "known", value: "2", unit: "ft" }
    });
    const lines = curbCostLines(quantities, PAGE60_RECIPE, EXAMPLE_PRICE_BOOK);
    const estimate = priceEstimate({
      trade: "curb",
      lines,
      recipe: "driveway-opening@1.0.0",
      policy: {
        currency: "USD",
        overheadRate: "0.10",
        price: { method: "target_margin", marginRate: "0.25" },
        revision: "package-1"
      }
    });
    return {
      cutLengthFt,
      directCost: estimate.scenarios?.base.directCost.amount ?? null,
      costBasis: estimate.scenarios?.base.costBasis.amount ?? null,
      total: estimate.scenarios?.base.total.amount ?? null,
      firm: estimate.firm,
      status: estimate.status,
      engineVersion: estimate.engineVersion
    };
  }
  function computeRoofExample() {
    const takeoff = roofTakeoff({
      facets: [300, 100, 200, 200, 100, 300].map((a, i) => ({
        id: `f${i}`,
        structureId: "house",
        planAreaM2: convertQuantity(String(a), "ft2", "m2").toString(),
        pitch: { rise: 6, run: 12 }
      })),
      edgeLengthsM: {
        eave: convertQuantity("160", "ft", "m").toString(),
        ridge: convertQuantity("40", "ft", "m").toString(),
        hip: convertQuantity("75", "ft", "m").toString(),
        valley: convertQuantity("15", "ft", "m").toString()
      }
    });
    const materials = materialTakeoff(takeoff, EXAMPLE_MATERIALS, {
      shingles: waste("0.10"),
      underlayment: waste("0"),
      ridge_cap: waste("0.10")
    });
    const lines = roofCostLines(takeoff, materials, EXAMPLE_MATERIALS, [EXAMPLE_LABOR]);
    const estimate = priceEstimate({
      trade: "roof",
      lines,
      recipe: "roof-takeoff@1.0.0",
      policy: {
        currency: "USD",
        overheadRate: "0.10",
        price: { method: "markup", markupRate: "0.30" },
        revision: "package-1"
      }
    });
    return {
      planFt2: convertQuantity(takeoff.property.planM2, "m2", "ft2").toString(),
      slopedFt2: takeoff.property.slopedFt2,
      squares: takeoff.property.squares,
      materialOrders: materials.map((m) => ({
        code: m.code,
        orderPacks: m.orderPacks,
        packUnit: m.packUnit,
        status: m.status
      })),
      directCost: estimate.scenarios?.base.directCost.amount ?? null,
      total: estimate.scenarios?.base.total.amount ?? null,
      firm: estimate.firm,
      status: estimate.status,
      engineVersion: estimate.engineVersion
    };
  }
  var FieldProCalc = {
    computeCurbExample,
    computeRoofExample,
    VERSION: "1.0.0"
  };
  if (typeof globalThis !== "undefined" && "document" in globalThis) {
    globalThis.FieldProCalc = FieldProCalc;
  }
})();
/*! Bundled license information:

decimal.js/decimal.mjs:
  (*!
   *  decimal.js v10.6.0
   *  An arbitrary-precision Decimal type for JavaScript.
   *  https://github.com/MikeMcl/decimal.js
   *  Copyright (c) 2025 Michael Mclaughlin <M8ch88l@gmail.com>
   *  MIT Licence
   *)
*/
//# sourceMappingURL=calc.js.map
