Field Pro — Contractor Calculator Package
========================================

This offline package includes the Field Pro roof and curb calculation engines.

How to run:
  1. Open index.html in a modern browser, or
  2. From this folder: python3 -m http.server 8765
     then visit http://localhost:8765

The full signed-in Field Pro workspace (projects, team, media, reports) runs as
the web application from the Field Pro repository / hosted deployment.

Rates shown in the worked examples are synthetic fixtures for verification,
not market quotes. Replace them with your approved price book in production use.
